# Exported from notebooks/01_benchmark_duplicate_audit_grouped_cv_gradcam.ipynb (the notebook is the version that produced the published results).
# The code was written for Kaggle Notebooks (GPU T4); inputs are found under INPUT_ROOT, outputs go to OUT (Cell 1).
# Shell commands of the notebook are kept as comments; install the packages in requirements.txt first.
try:
    from IPython.display import display
except ImportError:
    display = print

# %% [markdown]
# # Citrus v2 — leakage-controlled, shortcut-audited, explainable benchmark (KAGGLE version)
# 
# **Run guide (Kaggle)**
# 1. Right-hand panel → **Session options**: Accelerator = **GPU T4 x2**, **Internet = On**, Persistence = *Files only* (optional).
# 2. Right-hand panel → **Add Input** → *Your Datasets* → add **citrus-data** (it must contain `split_dataset.zip` and, if you have it, the `citrus_v2_results` folder downloaded from Google Drive).
# 3. Do **not** change any code except Cell 1 if I ask you to.
# 4. Top right: **Save Version** → *Save & Run All (Commit)* → **Save**. The run continues on Kaggle's server even if you close the browser (≈3–4 h).
# 5. When the version shows *Complete*, open it → **Output** tab → download **`citrus_v2_results_upload.zip`** (send it to me) and **`citrus_v2_expert_pack.zip`** (give it to the two experts). Keep `expert_key_DO_NOT_SHARE.csv` yourself; never send it to the experts.
# 
# Earlier Colab work (ResNet50 folds) is copied automatically from the input dataset and is **not** retrained, as long as the `citrus_v2_results` folder (with `tables/`, `oof/` and `weights/`) was uploaded.

# %% Cell 1 — Settings (change only this cell)   [notebook version 6.2 — KAGGLE]
#@title Cell 1 — Settings (change only this cell)   [notebook version 6.2 — KAGGLE]
SMOKE_TEST = False    # False = REAL run (all 1,834 images). True only for a quick code check.
SEED = 42
INPUT_ROOT = "/kaggle/input"   # Kaggle mounts added datasets here (read-only)
OUT = "/kaggle/working/citrus_v2_results"   # everything here appears in the Output tab
EXTERNAL_DIR = ""     # optional, e.g. "/kaggle/input/emon-sweet-orange/..." with Healthy/ Canker/ Greening/
MODELS = ["ResNet50", "MobileNetV2", "EfficientNetB0", "DenseNet121", "InceptionV3", "EfficientNetV2S", "ConvNeXtTiny"]
N_FOLDS = 5
HEAD_EP, FT_EP, FT_LAYERS, BATCH = 10, 8, 30, 32
COS_T, PH_T, PH_COS = 0.95, 6, 0.85   # duplicate if cosine >= COS_T, OR (rotation-invariant pHash <= PH_T AND cosine >= PH_COS)
LEAK_MODELS, LEAK_SEEDS = ["MobileNetV2", "DenseNet121"], [0, 1, 2]
import os
os.environ["CUDA_VISIBLE_DEVICES"] = "0"   # Kaggle T4 x2: use one GPU (same as the Colab runs)
os.environ["PYTHONHASHSEED"] = str(SEED)

# %% Cell 2 — Install, locate Kaggle inputs, restore earlier results, imports
#@title Cell 2 — Install, locate Kaggle inputs, restore earlier results, imports
# (shell) !pip -q install imagehash lime statsmodels
import glob, zipfile, json, math, random, time, hashlib, shutil
import numpy as np, pandas as pd
from PIL import Image
import matplotlib.pyplot as plt
CLS_CHECK = ["Black_Spot", "Canker", "Greening", "Healthy", "Melanose"]

def is_data_root(d):
    return (os.path.isdir(f"{d}/train") and os.path.isdir(f"{d}/test")
            and sum(os.path.isdir(f"{d}/train/{c}") for c in CLS_CHECK) >= 3)

# 1) Images: Kaggle normally unzips uploads; fall back to extracting split_dataset.zip ourselves
DATA = None
for root, dirs, files in os.walk(INPUT_ROOT):
    if is_data_root(root) and "SMOKE" not in root:
        DATA = root; break
if DATA is None:
    zips = [z for z in glob.glob(f"{INPUT_ROOT}/**/split_dataset*.zip", recursive=True)]
    assert zips, "split_dataset.zip not found. add the Kaggle dataset that contains split_dataset (see DATA.md) via Add Input."
    with zipfile.ZipFile(zips[0]) as z:
        z.extractall("/kaggle/temp/data")
    for root, dirs, files in os.walk("/kaggle/temp/data"):
        if is_data_root(root):
            DATA = root; break
assert DATA, "Image folders train/ val/ test/ <class>/ not found inside the dataset."
print("Images from:", DATA)

for sub in ["oof", "weights", "figures", "tables", "expert/images"]:
    os.makedirs(f"{OUT}/{sub}", exist_ok=True)

# 2) Earlier Colab results (ResNet50 folds, fold file): merge every non-SMOKE copy found in the inputs
prev_dirs = []
for root, dirs, files in os.walk(INPUT_ROOT):
    if "SMOKE" in root or "_upload" in root:
        continue
    if os.path.basename(root) == "citrus_v2_results" or (
            os.path.isdir(f"{root}/tables") and (os.path.isdir(f"{root}/weights") or os.path.isdir(f"{root}/oof"))):
        if not any(root.startswith(p + "/") for p in prev_dirs):
            prev_dirs.append(root)
LOG_KEYS = {"cv_log.csv": ["model", "fold"], "leakage_simulation.csv": ["protocol", "model", "seed"]}
logs = {k: [] for k in LOG_KEYS}
for p in prev_dirs:
    for k in LOG_KEYS:
        if os.path.exists(f"{p}/tables/{k}"):
            logs[k].append(pd.read_csv(f"{p}/tables/{k}"))
    shutil.copytree(p, OUT, dirs_exist_ok=True)
for k, keys in LOG_KEYS.items():          # union of all copies, so an older copy never hides newer finished work
    if logs[k]:
        u = pd.concat(logs[k], ignore_index=True).drop_duplicates(subset=keys, keep="last")
        u.to_csv(f"{OUT}/tables/{k}", index=False)
        print(f"{k}: {len(u)} finished runs restored")
print("Earlier results merged from:", prev_dirs if prev_dirs else "none (everything will be trained here)")

# keep finished folds whose out-of-fold prediction file exists (that is all the summary tables need);
# weights are needed only for the finally selected model and are re-created in Cell 8 if missing
LOG = f"{OUT}/tables/cv_log.csv"
if os.path.exists(LOG):
    lg = pd.read_csv(LOG)
    ok = [os.path.exists(f"{OUT}/oof/{m}_fold{k}.npz") for m, k in zip(lg.model, lg.fold)]
    dropped = lg[[not o for o in ok]]
    lg[ok].to_csv(LOG, index=False)
    nw = sum(os.path.exists(f"{OUT}/weights/{m}_fold{k}.weights.h5") for m, k in zip(lg[ok].model, lg[ok].fold))
    print("Finished folds restored:", len(lg[ok]), "| with weights:", nw,
          "| no prediction file, will retrain:", list(zip(dropped.model, dropped.fold)))
if not os.path.exists(f"{OUT}/tables/images_groups_folds.csv"):
    print("No earlier fold file: new grouped folds will be made (and all models trained on them).")

import tensorflow as tf
import keras
from keras import layers
assert keras.__version__.startswith("3"), "This notebook needs Keras 3; tell me the version printed below."
random.seed(SEED); np.random.seed(SEED); keras.utils.set_random_seed(SEED)
print("TF", tf.__version__, "| Keras", keras.__version__, "| GPU:", tf.config.list_physical_devices("GPU"))
if SMOKE_TEST:
    MODELS, N_FOLDS, HEAD_EP, FT_EP = MODELS[:2], 2, 1, 1
    LEAK_MODELS, LEAK_SEEDS = LEAK_MODELS[:1], [0]
    OUT = OUT + "_SMOKE"
    for sub in ["oof", "weights", "figures", "tables", "expert/images"]:
        os.makedirs(f"{OUT}/{sub}", exist_ok=True)

# %% Cell 3 — Pool all 1,834 images and tag source / organ
#@title Cell 3 — Pool all 1,834 images and tag source / organ
CLASSES = ["Black_Spot", "Canker", "Greening", "Healthy", "Melanose"]
NC = len(CLASSES)
rows = []
for split in ["train", "val", "test"]:
    for c in CLASSES:
        for f in sorted(glob.glob(f"{DATA}/{split}/{c}/*")):
            b = os.path.basename(f)
            src = "Rauf" if b.startswith("citrus_") else ("Silva" if b.startswith("archive1_") else "Other")
            organ = "leaf" if (src == "Rauf" and "Leaves" in b) else "fruit"
            rows.append(dict(path=f, file=b, cls=c, y=CLASSES.index(c), source=src, organ=organ, old_split=split))
df = pd.DataFrame(rows)
if SMOKE_TEST:
    df = df.groupby("cls", group_keys=False).apply(lambda g: g.sample(min(len(g), 12), random_state=SEED)).reset_index(drop=True)
N = len(df)
print(N, "images")
display(pd.crosstab([df.source, df.organ], df.cls, margins=True))

def load(p, size=224):
    return np.asarray(Image.open(p).convert("RGB").resize((size, size), Image.BILINEAR), dtype=np.uint8)
X = np.stack([load(p) for p in df.path])
Y = df.y.values.astype("int64")

# %% Cell 4 — Duplicate audit v2 (exact, rotation/flip-invariant pHash, embedding similarity)
#@title Cell 4 — Duplicate audit v2 (exact, rotation/flip-invariant pHash, embedding similarity)
import imagehash
df["md5"] = [hashlib.md5(open(p, "rb").read()).hexdigest() for p in df.path]
print("Exact duplicate files:", int(df.md5.duplicated().sum()))

def n_black_corners(x, s=12, thr=20):
    return int(sum(c.mean() < thr for c in [x[:s, :s], x[:s, -s:], x[-s:, :s], x[-s:, -s:]]))
df["black_corners"] = [n_black_corners(x) for x in X]
df["pre_rotated"] = df.black_corners >= 2
print("Images that look like pre-rotated copies (>=2 black corners):")
display(pd.crosstab(df.source, df.cls, values=df.pre_rotated.astype(int), aggfunc="sum", margins=True))

def dihedral(im):
    out = []
    for k in range(4):
        r = im.rotate(90 * k)
        out += [r, r.transpose(Image.FLIP_LEFT_RIGHT)]
    return out
H = np.zeros((N, 8), dtype=np.uint64)
for i in range(N):
    for t, v in enumerate(dihedral(Image.fromarray(X[i]))):
        H[i, t] = np.uint64(int(str(imagehash.phash(v)), 16))
def popcount64(a):
    return np.unpackbits(np.ascontiguousarray(a).view(np.uint8).reshape(a.shape + (8,)), axis=-1).sum(-1)
PH = np.full((N, N), 64, dtype=np.uint8)
for t in range(8):
    for s in range(0, N, 128):
        PH[s:s + 128] = np.minimum(PH[s:s + 128], popcount64(H[s:s + 128, 0][:, None] ^ H[None, :, t]))

emb = keras.applications.EfficientNetB0(include_top=False, pooling="avg", weights="imagenet")
E = np.zeros((N, int(emb.outputs[0].shape[-1])), dtype="float32")
for s in range(0, N, 128):
    xb = X[s:s + 128]
    f = 0
    for k in range(4):
        f = f + emb.predict(keras.applications.efficientnet.preprocess_input(np.rot90(xb, k, axes=(1, 2)).astype("float32")), verbose=0)
    E[s:s + 128] = f / 4
E /= np.linalg.norm(E, axis=1, keepdims=True)
COS = E @ E.T

same = Y[:, None] == Y[None, :]
near = (COS >= COS_T) | ((PH <= PH_T) & (COS >= PH_COS))
np.fill_diagonal(near, False)
link = near & same
parent = list(range(N))
def find(a):
    while parent[a] != a:
        parent[a] = parent[parent[a]]; a = parent[a]
    return a
for i, j in zip(*np.where(np.triu(link))):
    ri, rj = find(i), find(j)
    if ri != rj: parent[ri] = rj
df["group"] = [find(i) for i in range(N)]
gs = df.groupby("group").size()
print(f"Near-duplicate groups (size>1): {(gs > 1).sum()} | images in them: {gs[gs > 1].sum()} | largest group: {gs.max()}")
display(df[df.group.map(gs) > 1].groupby(["source", "cls"]).size().unstack(fill_value=0))
if not SMOKE_TEST and gs.max() > 0.03 * N:
    print(f"WARNING: largest group has {gs.max()} images (>3% of all) — thresholds may be too loose; set COS_T = 0.97 in Cell 1 and rerun.")

# How leaky was the OLD split?
train_groups = set(df.group[df.old_split == "train"])
old_test = df.old_split == "test"
leak_old = old_test & df.group.isin(train_groups)
print(f"OLD split: {leak_old.sum()} of {old_test.sum()} old-test images had a near-duplicate in old-train")
display(df[leak_old].groupby(["source", "cls"]).size())

cross = np.argwhere(np.triu(near & ~same))
pd.DataFrame([dict(file_a=df.file[i], cls_a=df.cls[i], file_b=df.file[j], cls_b=df.cls[j], cos=round(float(COS[i, j]), 3), phash=int(PH[i, j])) for i, j in cross]).to_csv(f"{OUT}/tables/cross_class_near_duplicates.csv", index=False)
print("Cross-class near-duplicate pairs (possible label conflicts):", len(cross))

def show_pairs(lo, hi, fname, k=10):
    iu = np.argwhere(np.triu(same, 1) & (COS >= lo) & (COS < hi))
    if len(iu) == 0: return
    sel = iu[np.random.default_rng(SEED).choice(len(iu), min(k, len(iu)), replace=False)]
    fig, ax = plt.subplots(len(sel), 2, figsize=(4, 2 * len(sel)))
    ax = np.atleast_2d(ax)
    for r, (i, j) in enumerate(sel):
        ax[r, 0].imshow(X[i]); ax[r, 1].imshow(X[j]); ax[r, 0].set_title(f"cos {COS[i, j]:.3f} | pH {PH[i, j]}", fontsize=7)
        ax[r, 0].axis("off"); ax[r, 1].axis("off")
    plt.tight_layout(); plt.savefig(f"{OUT}/figures/{fname}", dpi=120); plt.close()
show_pairs(COS_T, 1.01, "dup_pairs_just_above_threshold.png")
show_pairs(COS_T - 0.03, COS_T, "dup_pairs_just_below_threshold.png")
df.drop(columns=["path"]).to_csv(f"{OUT}/tables/images_groups.csv", index=False)
# free memory used by the audit
del COS, PH, E, H, emb, near, link, same
import gc; gc.collect()

# %% Cell 5 — Grouped, stratified 5-fold cross-validation splits
#@title Cell 5 — Grouped, stratified 5-fold cross-validation splits
from sklearn.model_selection import StratifiedGroupKFold
FOLD_CSV = f"{OUT}/tables/images_groups_folds.csv"
reused = False
if os.path.exists(FOLD_CSV):
    prev = pd.read_csv(FOLD_CSV)
    kp = prev.old_split + "|" + prev.cls + "|" + prev.file
    kd = df.old_split + "|" + df.cls + "|" + df.file
    if len(prev) == N and kd.isin(set(kp)).all():
        df["group"] = kd.map(dict(zip(kp, prev.group))).values
        df["fold"] = kd.map(dict(zip(kp, prev.fold))).values.astype(int)
        reused = True
        print("Re-using the group and fold assignment saved by the earlier run (finished folds stay valid).")
G = df.group.values
if not reused:
    sgkf = StratifiedGroupKFold(n_splits=N_FOLDS, shuffle=True, random_state=SEED)
    df["fold"] = -1
    for k, (_, te) in enumerate(sgkf.split(np.zeros(N), Y, G)):
        df.loc[te, "fold"] = k
display(pd.crosstab(df.fold, df.cls))

def split_fold(k):
    te = np.where(df.fold.values == k)[0]
    rest = np.where(df.fold.values != k)[0]
    inner = StratifiedGroupKFold(n_splits=6, shuffle=True, random_state=SEED + k)
    tr_i, va_i = next(inner.split(np.zeros(len(rest)), Y[rest], G[rest]))
    return rest[tr_i], rest[va_i], te
for k in range(N_FOLDS):
    tr, va, te = split_fold(k)
    assert not (set(G[tr]) & set(G[te])) and not (set(G[va]) & set(G[te])) and not (set(G[tr]) & set(G[va]))
print("Check passed: no near-duplicate group is shared between train, validation and test in any fold.")
df.drop(columns=["path"]).to_csv(f"{OUT}/tables/images_groups_folds.csv", index=False)

# %% Cell 6 — Models, data pipeline, training helpers
#@title Cell 6 — Models, data pipeline, training helpers
APPS = {
    "ResNet50": (keras.applications.ResNet50, keras.applications.resnet.preprocess_input),
    "MobileNetV2": (keras.applications.MobileNetV2, keras.applications.mobilenet_v2.preprocess_input),
    "EfficientNetB0": (keras.applications.EfficientNetB0, keras.applications.efficientnet.preprocess_input),
    "DenseNet121": (keras.applications.DenseNet121, keras.applications.densenet.preprocess_input),
    "InceptionV3": (keras.applications.InceptionV3, keras.applications.inception_v3.preprocess_input),
    "EfficientNetV2S": (keras.applications.EfficientNetV2S, keras.applications.efficientnet_v2.preprocess_input),
    "ConvNeXtTiny": (keras.applications.ConvNeXtTiny, keras.applications.convnext.preprocess_input),
}
AUTOTUNE = tf.data.AUTOTUNE
AUG = keras.Sequential([layers.RandomFlip("horizontal_and_vertical"), layers.RandomRotation(0.1), layers.RandomZoom(0.2),
                        layers.RandomContrast(0.2), layers.RandomBrightness(0.2, value_range=(0, 255))])

def build_model(name, n_out):
    ctor, _ = APPS[name]
    inp = keras.Input((224, 224, 3))
    base = ctor(include_top=False, weights=None if SMOKE_TEST else "imagenet", input_tensor=inp)
    x = layers.GlobalAveragePooling2D()(base.output)
    x = layers.Dropout(0.3)(x)
    out = layers.Dense(n_out, activation="softmax", dtype="float32")(x)
    return keras.Model(inp, out), base

def _batch_index(ya, seed, n_batches):
    """Square-root class-balanced sampling with replacement (same rule as before), as a fixed index table."""
    rng = np.random.default_rng(seed)
    cls = np.unique(ya); idx = [np.where(ya == c)[0] for c in cls]
    w = np.sqrt([len(i) for i in idx]); w = w / w.sum()
    out = np.empty((n_batches, BATCH), dtype="int64")
    for b in range(n_batches):
        cs = rng.choice(len(cls), size=BATCH, p=w)
        out[b] = [rng.choice(idx[c]) for c in cs]
    return out

def train_ds(Xa, ya, prep):
    with tf.device("/CPU:0"):
        Xt = tf.convert_to_tensor(Xa); yt = tf.convert_to_tensor(np.asarray(ya, dtype="int64"))
    steps = max(1, math.ceil(len(ya) / BATCH))
    ds = tf.data.Dataset.from_tensor_slices(_batch_index(np.asarray(ya), SEED, steps * max(HEAD_EP, FT_EP))).repeat()
    ds = ds.map(lambda i: (tf.gather(Xt, i), tf.gather(yt, i)))
    return ds.map(lambda x, y: (prep(AUG(tf.cast(x, tf.float32), training=True)), y), num_parallel_calls=AUTOTUNE).prefetch(2)

def eval_ds(Xa, prep, ya=None, fn=None):
    if fn is not None:
        Xa = np.stack([fn(x) for x in Xa])
    if ya is None:
        return tf.data.Dataset.from_tensor_slices(Xa).batch(BATCH).map(lambda x: prep(tf.cast(x, tf.float32))).prefetch(2)
    ds = tf.data.Dataset.from_tensor_slices((Xa, np.asarray(ya, dtype="int64"))).batch(BATCH)
    return ds.map(lambda x, y: (prep(tf.cast(x, tf.float32)), y)).prefetch(2)

def ram_gb():
    try:
        import psutil; return psutil.Process().memory_info().rss / 1e9
    except Exception:
        return float("nan")
def ram_limit_gb():
    try:
        import psutil; return 0.75 * psutil.virtual_memory().total / 1e9
    except Exception:
        return 1e9

def free_memory(*objs):
    import gc
    for o in objs: del o
    keras.backend.clear_session(); gc.collect(); gc.collect()

def train_one(name, Xtr, ytr, Xva, yva, n_out):
    keras.backend.clear_session(); keras.utils.set_random_seed(SEED)
    model, base = build_model(name, n_out)
    prep = APPS[name][1]
    tr, va = train_ds(Xtr, ytr, prep), eval_ds(Xva, prep, yva)
    steps = max(1, math.ceil(len(ytr) / BATCH))
    loss = "sparse_categorical_crossentropy"
    for l in base.layers: l.trainable = False
    model.compile(optimizer=keras.optimizers.Adam(1e-3), loss=loss, metrics=["accuracy"])
    model.fit(tr, validation_data=va, epochs=HEAD_EP, steps_per_epoch=steps, verbose=0,
              callbacks=[keras.callbacks.EarlyStopping(monitor="val_loss", patience=3, restore_best_weights=True)])
    for l in base.layers[-FT_LAYERS:]:
        if not isinstance(l, layers.BatchNormalization): l.trainable = True
    model.compile(optimizer=keras.optimizers.Adam(1e-5), loss=loss, metrics=["accuracy"])
    model.fit(tr, validation_data=va, epochs=FT_EP, steps_per_epoch=steps, verbose=0,
              callbacks=[keras.callbacks.EarlyStopping(monitor="val_loss", patience=3, restore_best_weights=True)])
    return model, base

def predict_u8(model, name, Xa, fn=None):
    return model.predict(eval_ds(Xa, APPS[name][1], fn=fn), verbose=0)

def centre_only(x, keep=0.7):
    h = x.shape[0]; m = int(h * (1 - keep) / 2)
    out = np.full_like(x, 124); out[m:h - m, m:h - m] = x[m:h - m, m:h - m]; return out
def corners_only(x, s=56):
    h = x.shape[0]; out = np.full_like(x, 124)
    for r, c in [(0, 0), (0, h - s), (h - s, 0), (h - s, h - s)]:
        out[r:r + s, c:c + s] = x[r:r + s, c:c + s]
    return out

# %% Cell 7 — Train all models with 5-fold grouped CV (resumable)
#@title Cell 7 — Train all models with 5-fold grouped CV (resumable)
from sklearn.metrics import f1_score, accuracy_score
LOG = f"{OUT}/tables/cv_log.csv"
done = pd.read_csv(LOG) if os.path.exists(LOG) else pd.DataFrame(columns=["model", "fold"])
def mf1(y, p): return f1_score(y, p, average="macro", labels=np.unique(y), zero_division=0)
for name in MODELS:
    for k in range(N_FOLDS):
        if ((done.model == name) & (done.fold == k)).any():
            print("skip (already done):", name, k); continue
        t0 = time.time()
        tr, va, te = split_fold(k)
        model, base = train_one(name, X[tr], Y[tr], X[va], Y[va], NC)
        pv, pt = predict_u8(model, name, X[va]), predict_u8(model, name, X[te])
        pc = predict_u8(model, name, X[te], fn=centre_only)
        pk = predict_u8(model, name, X[te], fn=corners_only)
        np.savez_compressed(f"{OUT}/oof/{name}_fold{k}.npz", te=te, p_full=pt, p_centre=pc, p_corners=pk)
        wpath = f"{OUT}/weights/{name}_fold{k}.weights.h5"
        model.save_weights(wpath)
        row = dict(model=name, fold=k, n_train=len(tr), n_val=len(va), n_test=len(te),
                   val_macro_f1=mf1(Y[va], pv.argmax(1)), test_acc=accuracy_score(Y[te], pt.argmax(1)),
                   test_macro_f1=mf1(Y[te], pt.argmax(1)), params_M=model.count_params() / 1e6,
                   weights_MB=os.path.getsize(wpath) / 1e6, minutes=(time.time() - t0) / 60)
        done = pd.concat([done, pd.DataFrame([row])], ignore_index=True); done.to_csv(LOG, index=False)
        print({k_: (round(v, 3) if isinstance(v, float) else v) for k_, v in row.items()})
        del model, base, pv, pt, pc, pk
        free_memory()

# %% Cell 8 — Summary tables: accuracy with CIs, McNemar tests, per-class / per-source / per-organ results
#@title Cell 8 — Summary tables: accuracy with CIs, McNemar tests, per-class / per-source / per-organ results
from statsmodels.stats.proportion import proportion_confint
from statsmodels.stats.contingency_tables import mcnemar
from sklearn.metrics import classification_report, confusion_matrix
log = pd.read_csv(LOG)
def oof(name, key="p_full"):
    P = np.zeros((N, NC)); seen = np.zeros(N, bool)
    for k in range(N_FOLDS):
        z = np.load(f"{OUT}/oof/{name}_fold{k}.npz"); P[z["te"]] = z[key]; seen[z["te"]] = True
    assert seen.all(), name
    return P
rng = np.random.default_rng(SEED)
def boot_f1(y, p, B=1000):
    v = [f1_score(y[i], p[i], average="macro", zero_division=0) for i in (rng.integers(0, len(y), len(y)) for _ in range(B))]
    return np.percentile(v, [2.5, 97.5])
m4 = Y != CLASSES.index("Melanose")
majority = np.bincount(Y).max() / N
rows, preds = [], {}
for name in MODELS:
    if not os.path.exists(f"{OUT}/oof/{name}_fold{N_FOLDS - 1}.npz"): continue
    yp = oof(name).argmax(1); preds[name] = yp
    c = int((yp == Y).sum()); lo, hi = proportion_confint(c, N, method="wilson"); flo, fhi = boot_f1(Y, yp)
    lg = log[log.model == name]
    rows.append(dict(model=name, val_macro_f1_mean=lg.val_macro_f1.mean(), correct=c, n=N, acc=c / N, acc_ci95=f"{lo:.3f}-{hi:.3f}",
                     macro_f1=f1_score(Y, yp, average="macro"), macro_f1_ci95=f"{flo:.3f}-{fhi:.3f}",
                     macro_f1_4class=f1_score(Y[m4], yp[m4], average="macro", labels=[0, 1, 2, 3]),
                     fold_acc_mean=lg.test_acc.mean(), fold_acc_sd=lg.test_acc.std(),
                     acc_Rauf=(yp == Y)[df.source.values == "Rauf"].mean(), acc_Silva=(yp == Y)[df.source.values == "Silva"].mean(),
                     acc_leaf=(yp == Y)[df.organ.values == "leaf"].mean(), acc_fruit=(yp == Y)[df.organ.values == "fruit"].mean(),
                     acc_centre_only=(oof(name, "p_centre").argmax(1) == Y).mean(),
                     acc_corners_only=(oof(name, "p_corners").argmax(1) == Y).mean(),
                     params_M=lg.params_M.iloc[0], weights_MB=lg.weights_MB.iloc[0]))
S = pd.DataFrame(rows).sort_values("val_macro_f1_mean", ascending=False).reset_index(drop=True)
BEST = S.model.iloc[0]          # chosen on VALIDATION macro-F1, never on test
pv = []
for name in S.model:
    if name == BEST: pv.append(np.nan); continue
    a, b = preds[BEST] == Y, preds[name] == Y
    pv.append(mcnemar([[np.sum(a & b), np.sum(a & ~b)], [np.sum(~a & b), np.sum(~a & ~b)]], exact=True).pvalue)
S["mcnemar_p_vs_selected"] = pv
order_ = np.argsort([p if p == p else 9 for p in pv]); m_ = np.sum([p == p for p in pv]); adj = [np.nan] * len(pv); run = 0
for r, i in enumerate(order_):
    if pv[i] != pv[i]: continue
    run = max(run, min(1, (m_ - r) * pv[i])); adj[i] = run
S["holm_p"] = adj
S.to_csv(f"{OUT}/tables/model_summary.csv", index=False)
print(f"Selected by mean validation macro-F1: {BEST} | majority-class baseline = {majority:.3f}")
display(S.round(3))
yp = preds[BEST]
pd.DataFrame(classification_report(Y, yp, labels=list(range(NC)), target_names=CLASSES, digits=3, output_dict=True, zero_division=0)).T.to_csv(f"{OUT}/tables/per_class_{BEST}.csv")
print(classification_report(Y, yp, labels=list(range(NC)), target_names=CLASSES, digits=3, zero_division=0))
cm = confusion_matrix(Y, yp, labels=list(range(NC)))
fig, ax = plt.subplots(figsize=(5, 4.2)); ax.imshow(cm, cmap="Blues")
for i in range(NC):
    for j in range(NC): ax.text(j, i, cm[i, j], ha="center", va="center", color="white" if cm[i, j] > cm.max() / 2 else "black")
ax.set_xticks(range(NC), CLASSES, rotation=45, ha="right"); ax.set_yticks(range(NC), CLASSES)
ax.set_xlabel("Predicted"); ax.set_ylabel("Actual"); ax.set_title(f"{BEST}: pooled out-of-fold predictions (n={N})")
plt.tight_layout(); plt.savefig(f"{OUT}/figures/confusion_{BEST}.png", dpi=300); plt.close()
t = df.assign(correct=(yp == Y)).groupby(["source", "organ", "cls"]).correct.agg(["mean", "size"]).round(3)
t.to_csv(f"{OUT}/tables/acc_by_source_organ_class_{BEST}.csv"); display(t)

# --- Kaggle: make sure the selected model has weights for every fold (needed by Cells 10-11) ---
for k in range(N_FOLDS):
    wpath = f"{OUT}/weights/{BEST}_fold{k}.weights.h5"
    if not os.path.exists(wpath):
        print(f"Weights for {BEST} fold {k} not found (download was split); re-training this fold for the explanation tests ...")
        tr, va, te = split_fold(k)
        model, base = train_one(BEST, X[tr], Y[tr], X[va], Y[va], NC)
        model.save_weights(wpath)
        del model, base; free_memory()
print("Weights available for", BEST, "folds:", [k for k in range(N_FOLDS) if os.path.exists(f"{OUT}/weights/{BEST}_fold{k}.weights.h5")])

# %% Cell 9 — Leakage simulation on the Sargodha leaves (why other papers report 96–99%)
#@title Cell 9 — Leakage simulation on the Sargodha leaves (why other papers report 96–99%)
from sklearn.model_selection import train_test_split
def aug_offline(x, rng):
    im = Image.fromarray(x).rotate(90 * int(rng.integers(0, 4)))
    if rng.random() < .5: im = im.transpose(Image.FLIP_LEFT_RIGHT)
    if rng.random() < .5: im = im.transpose(Image.FLIP_TOP_BOTTOM)
    return np.asarray(im.rotate(float(rng.uniform(-30, 30))))
def balance(idx, target, rng):
    xs, ys, src = [], [], []
    for c in np.unique(Y[idx]):
        ic = idx[Y[idx] == c]
        xs += [X[i] for i in ic]; ys += [c] * len(ic); src += list(ic)
        for j in range(max(0, target - len(ic))):
            i = ic[j % len(ic)]; xs.append(aug_offline(X[i], rng)); ys.append(c); src.append(i)
    return np.stack(xs), np.array(ys, dtype="int64"), np.array(src)
leaf = np.where((df.source.values == "Rauf") & (df.organ.values == "leaf"))[0]
TARGET = 15 if SMOKE_TEST else 204
LEAK_LOG = f"{OUT}/tables/leakage_simulation.csv"
L = pd.read_csv(LEAK_LOG) if os.path.exists(LEAK_LOG) else pd.DataFrame(columns=["protocol", "model", "seed"])
for name in LEAK_MODELS:
    for s in LEAK_SEEDS:
        rng = np.random.default_rng(s)
        if not ((L.protocol == "A") & (L.model == name) & (L.seed == s)).any():
            Xa, ya, sa = balance(leaf, TARGET, rng)                     # A: augment first, then split (naive)
            tr, te = train_test_split(np.arange(len(ya)), test_size=0.3, stratify=ya, random_state=s)
            tr, va = train_test_split(tr, test_size=0.15, stratify=ya[tr], random_state=s)
            if ram_gb() > ram_limit_gb():
                L.to_csv(LEAK_LOG, index=False)
                raise RuntimeError(f"RAM {ram_gb():.1f} GB is close to the limit. Finished runs are saved: run the notebook again and it continues from here.")
            m, _ = train_one(name, Xa[tr], ya[tr], Xa[va], ya[va], NC)
            p = predict_u8(m, name, Xa[te]).argmax(1)
            del m, Xa; free_memory()
            L = pd.concat([L, pd.DataFrame([dict(protocol="A", description="augment then random 70:30 split", model=name, seed=s, n_test=len(te),
                acc=accuracy_score(ya[te], p), macro_f1=mf1(ya[te], p), test_shares_original_with_train=np.isin(sa[te], sa[tr]).mean())])], ignore_index=True)
        if not ((L.protocol == "B") & (L.model == name) & (L.seed == s)).any():
            g = G[leaf]                                                  # B: group split first, augment training only
            o_tr, o_te = next(StratifiedGroupKFold(n_splits=3, shuffle=True, random_state=s).split(np.zeros(len(leaf)), Y[leaf], g))
            o_tr, o_te = leaf[o_tr], leaf[o_te]
            i_tr, i_va = next(StratifiedGroupKFold(n_splits=5, shuffle=True, random_state=s).split(np.zeros(len(o_tr)), Y[o_tr], G[o_tr]))
            Xb, yb, _ = balance(o_tr[i_tr], int(TARGET * 0.7), rng)
            if ram_gb() > ram_limit_gb():
                L.to_csv(LEAK_LOG, index=False)
                raise RuntimeError(f"RAM {ram_gb():.1f} GB is close to the limit. Finished runs are saved: run the notebook again and it continues from here.")
            m, _ = train_one(name, Xb, yb, X[o_tr[i_va]], Y[o_tr[i_va]], NC)
            p = predict_u8(m, name, X[o_te]).argmax(1)
            del m, Xb; free_memory()
            L = pd.concat([L, pd.DataFrame([dict(protocol="B", description="group split, augment training only, test on originals", model=name, seed=s,
                n_test=len(o_te), acc=accuracy_score(Y[o_te], p), macro_f1=mf1(Y[o_te], p), test_shares_original_with_train=0.0)])], ignore_index=True)
        L.to_csv(LEAK_LOG, index=False)
        print(f"leakage simulation: {name} seed {s} done | RAM in use {ram_gb():.1f} GB")
display(L.groupby(["protocol", "model"])[["acc", "macro_f1", "test_shares_original_with_train"]].agg(["mean", "std"]).round(3))

# %% Cell 10 — Shortcut probes, organ-matched cross-source test, optional external test
#@title Cell 10 — Shortcut probes, organ-matched cross-source test, optional external test
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import cross_val_predict
from sklearn.metrics import roc_auc_score
fe = keras.applications.MobileNetV2(include_top=False, pooling="avg", weights="imagenet")
def feats(Xa):
    return np.concatenate([fe.predict(keras.applications.mobilenet_v2.preprocess_input(Xa[s:s + 128].astype("float32")), verbose=0) for s in range(0, len(Xa), 128)])
def safe_cvp(F, t, groups, k=5, proba=False):
    """Grouped CV predictions; folds reduced if a class has few groups; returns None if impossible."""
    k = int(min(k, pd.Series(groups).groupby(t).nunique().min()))
    if k < 2 or len(np.unique(t)) < 2:
        print("  probe skipped (too few groups per class)"); return None
    try:
        return cross_val_predict(LogisticRegression(max_iter=3000), F, t, groups=groups,
                                 cv=StratifiedGroupKFold(n_splits=k, shuffle=True, random_state=SEED),
                                 method="predict_proba" if proba else "predict")
    except Exception as e:
        print("  probe skipped:", type(e).__name__, e); return None
F_full = feats(X)
F_corn = np.concatenate([feats(np.stack([corners_only(x) for x in X[s:s + 256]])) for s in range(0, N, 256)])
probe = []
for nm, F in [("full image", F_full), ("corner patches only", F_corn)]:
    p = safe_cvp(F, Y, G)
    if p is not None:
        probe.append(dict(input=nm, target="disease class", acc=accuracy_score(Y, p), macro_f1=f1_score(Y, p, average="macro"), majority=majority))
src = (df.source.values == "Silva").astype(int)
for nm, F in [("full image", F_full), ("corner patches only", F_corn)]:
    pr = safe_cvp(F, src, G, proba=True)
    if pr is not None:
        probe.append(dict(input=nm, target="dataset source (Rauf vs Silva)", acc=accuracy_score(src, pr[:, 1] > .5),
                          auc=roc_auc_score(src, pr[:, 1]), majority=max(src.mean(), 1 - src.mean())))
for c in ["Black_Spot", "Canker", "Greening", "Healthy"]:
    ii = np.where(df.cls.values == c)[0]
    pr = safe_cvp(F_full[ii], src[ii], G[ii], k=3, proba=True)
    if pr is not None:
        probe.append(dict(input="full image", target=f"source within class {c}", auc=roc_auc_score(src[ii], pr[:, 1])))
P_ = pd.DataFrame(probe); P_.to_csv(f"{OUT}/tables/shortcut_probes.csv", index=False); display(P_.round(3))

SHARED = ["Black_Spot", "Canker", "Greening", "Healthy"]
def sub(mask):
    ii = np.where(mask & np.isin(df.cls.values, SHARED))[0]
    return ii, np.array([SHARED.index(c) for c in df.cls.values[ii]], dtype="int64")
def run_transfer(train_mask, tests):
    ii, yy = sub(train_mask)
    if len(np.unique(yy)) < 2:
        print("  transfer skipped (training source has <2 classes)"); return []
    k = int(min(6, pd.Series(G[ii]).groupby(yy).nunique().min()))
    if k < 2:
        print("  transfer skipped (too few groups)"); return []
    tr_i, va_i = next(StratifiedGroupKFold(n_splits=k, shuffle=True, random_state=SEED).split(np.zeros(len(ii)), yy, G[ii]))
    m, _ = train_one(BEST, X[ii[tr_i]], yy[tr_i], X[ii[va_i]], yy[va_i], len(SHARED))
    out = []
    for nm, tmask in tests:
        jj, yj = sub(tmask)
        if len(jj) == 0: continue
        p = predict_u8(m, BEST, X[jj]).argmax(1); c = int((p == yj).sum()); lo, hi = proportion_confint(c, len(jj), method="wilson")
        out.append(dict(test=nm, n=len(jj), acc=c / len(jj), acc_ci95=f"{lo:.3f}-{hi:.3f}",
                        macro_f1=f1_score(yj, p, average="macro", labels=range(len(SHARED)), zero_division=0)))
    del m; free_memory()
    return out
def cached_transfer(tag, train_mask, tests):
    f = f"{OUT}/tables/cross_source_part_{tag}.csv"
    if os.path.exists(f):
        print("skip (already done): transfer", tag); return pd.read_csv(f).to_dict("records")
    r = run_transfer(train_mask, tests); pd.DataFrame(r).to_csv(f, index=False)
    print(f"transfer {tag} done | RAM in use {ram_gb():.1f} GB"); return r
R1 = cached_transfer("silva_to_rauf", df.source.values == "Silva", [("Silva -> Rauf FRUIT (organ-matched)", (df.source.values == "Rauf") & (df.organ.values == "fruit")),
                                                ("Silva -> Rauf LEAVES (organ-mismatched)", (df.source.values == "Rauf") & (df.organ.values == "leaf"))])
R2 = cached_transfer("rauf_to_silva", df.source.values == "Rauf", [("Rauf -> Silva fruit", df.source.values == "Silva")])
T_ = pd.DataFrame(R1 + R2); T_.to_csv(f"{OUT}/tables/cross_source_{BEST}.csv", index=False); display(T_)

if EXTERNAL_DIR and os.path.isdir(EXTERNAL_DIR):
    ext = [(f, c) for c in ["Healthy", "Canker", "Greening"] for f in sorted(glob.glob(f"{EXTERNAL_DIR}/{c}/*"))]
    Xe = np.stack([load(f) for f, _ in ext]); ye = np.array([CLASSES.index(c) for _, c in ext])
    Pe = 0
    for k in range(N_FOLDS):
        m, _ = build_model(BEST, NC); m.load_weights(f"{OUT}/weights/{BEST}_fold{k}.weights.h5"); Pe = Pe + predict_u8(m, BEST, Xe)
    keep = [CLASSES.index(c) for c in ["Healthy", "Canker", "Greening"]]
    pe = np.array(keep)[Pe[:, keep].argmax(1)]
    c = int((pe == ye).sum()); lo, hi = proportion_confint(c, len(ye), method="wilson")
    ext_res = dict(n=len(ye), acc=c / len(ye), acc_ci95=f"{lo:.3f}-{hi:.3f}", macro_f1=f1_score(ye, pe, average="macro"))
    pd.DataFrame([ext_res]).to_csv(f"{OUT}/tables/external_test_{BEST}.csv", index=False); print("External test:", ext_res)
    print(confusion_matrix(ye, pe, labels=keep))

# %% Cell 11 — Quantitative explanation tests for the selected model (Grad-CAM)
#@title Cell 11 — Quantitative explanation tests for the selected model (Grad-CAM)
from scipy import ndimage as ndi
from scipy.stats import spearmanr
from skimage import color, filters, measure
trap = getattr(np, "trapezoid", None) or np.trapz
def object_mask(x):
    """Leaf/fruit mask on plain backgrounds. Black padding or black backdrops are treated as background.
    Returns None when the mask is unreliable (cluttered field scenes, fragmented or tiny/huge masks)."""
    fill = x.max(axis=-1) < 25
    lab = color.rgb2lab(x)
    ring = np.zeros(x.shape[:2], bool); ring[:8] = ring[-8:] = True; ring[:, :8] = ring[:, -8:] = True
    bsel = ring & ~fill
    if bsel.sum() < 0.25 * ring.sum():          # border is mostly black: dark backdrop or padding
        m = ndi.binary_opening(x.max(axis=-1) >= 40, structure=np.ones((5, 5)))
    else:
        d = np.linalg.norm(lab - np.median(lab[bsel], 0), axis=-1); d[fill] = 0
        if (~fill).sum() < 100 or np.ptp(d[~fill]) == 0: return None
        m = ndi.binary_opening(d > filters.threshold_otsu(d[~fill]), structure=np.ones((5, 5))) & ~fill
    lbl = measure.label(m)
    if lbl.max() == 0: return None
    h = x.shape[0]; c0, c1 = h // 4, 3 * h // 4
    centre = np.bincount(lbl[c0:c1, c0:c1].ravel(), minlength=lbl.max() + 1)[1:]
    if centre.max() == 0: return None
    m = ndi.binary_fill_holes(lbl == (int(np.argmax(centre)) + 1))
    if not (0.05 < m.mean() < 0.95): return None
    if measure.regionprops(m.astype(np.uint8))[0].solidity < 0.6: return None   # fragmented -> unreliable
    return m
def gradcam(gm, Xu8, prep, cls):
    xt = tf.convert_to_tensor(prep(Xu8.astype("float32")))
    with tf.GradientTape() as tape:
        A, P = gm(xt, training=False)
        sc = tf.reduce_sum(P * tf.one_hot(cls, P.shape[-1]), axis=1)
    g = tape.gradient(sc, A)
    cam = tf.nn.relu(tf.reduce_sum(tf.reduce_mean(g, axis=(1, 2), keepdims=True) * A, axis=-1))
    cam = cam / (tf.reduce_max(cam, axis=(1, 2), keepdims=True) + 1e-8)
    return tf.image.resize(cam[..., None], (224, 224)).numpy()[..., 0]
def del_ins(m, prep, x, cam, cls, order=None, steps=10):
    order = np.argsort(-cam.ravel()) if order is None else order
    blur = ndi.gaussian_filter(x.astype("float32"), sigma=(10, 10, 0))
    D, I = [], []
    for s in range(steps + 1):
        mk = np.zeros(cam.size, bool); mk[order[: int(cam.size * s / steps)]] = True; mk = mk.reshape(cam.shape)[..., None]
        D.append(np.where(mk, blur, x)); I.append(np.where(mk, x, blur))
    p = m.predict(prep(np.stack(D + I).astype("float32")), verbose=0)[:, cls]
    return trap(p[:steps + 1], dx=1 / steps), trap(p[steps + 1:], dx=1 / steps)
prep = APPS[BEST][1]; DEL_PER_FOLD = 4 if SMOKE_TEST else 40
rows, curves_example = [], []
for k in range(N_FOLDS):
    m, base = build_model(BEST, NC); m.load_weights(f"{OUT}/weights/{BEST}_fold{k}.weights.h5")
    gm = keras.Model(m.inputs, [base.output, m.output])
    te = np.where(df.fold.values == k)[0]
    pr = predict_u8(m, BEST, X[te]); pc = pr.argmax(1)
    cams = np.concatenate([gradcam(gm, X[te[s:s + 32]], prep, pc[s:s + 32]) for s in range(0, len(te), 32)])
    dsel = set(np.random.default_rng(SEED + k).choice(len(te), min(DEL_PER_FOLD, len(te)), replace=False))
    for j, i in enumerate(te):
        om = object_mask(X[i]); cam = cams[j]
        r = dict(idx=i, fold=k, cls=CLASSES[Y[i]], pred=CLASSES[pc[j]], correct=bool(pc[j] == Y[i]), conf=float(pr[j].max()),
                 source=df.source.values[i], organ=df.organ.values[i], mask_ok=om is not None)
        if om is not None:
            r.update(object_area=float(om.mean()), cam_on_object=float((cam * om).sum() / (cam.sum() + 1e-8)),
                     pointing_hit=bool(om.ravel()[cam.argmax()]))
        if j in dsel:
            r["deletion_auc"], r["insertion_auc"] = del_ins(m, prep, X[i], cam, pc[j])
            r["deletion_auc_random"], r["insertion_auc_random"] = del_ins(m, prep, X[i], cam, pc[j], order=np.random.default_rng(i).permutation(cam.size))
        rows.append(r)
    if k == 0:   # model-randomisation sanity check (Adebayo et al. 2018)
        wl = [l for l in m.layers if l.get_weights()]
        mr, br = build_model(BEST, NC); mr.load_weights(f"{OUT}/weights/{BEST}_fold{k}.weights.h5")
        wlr = [l for l in mr.layers if l.get_weights()]
        for l in wlr[-max(1, int(len(wlr) * 0.2)):]:
            l.set_weights([np.random.default_rng(SEED).permutation(w.ravel()).reshape(w.shape) for w in l.get_weights()])
        gmr = keras.Model(mr.inputs, [br.output, mr.output])
        ns = min(50, len(te)); camr = gradcam(gmr, X[te[:ns]], prep, pc[:ns])
        rho = [spearmanr(cams[j][::4, ::4].ravel(), camr[j][::4, ::4].ravel()).correlation for j in range(ns)]
        pd.DataFrame(dict(idx=te[:ns], spearman_trained_vs_randomised=rho)).to_csv(f"{OUT}/tables/xai_randomisation_check.csv", index=False)
        print(f"Randomisation check: median Spearman = {np.nanmedian(rho):.2f} (high = explanation does NOT depend on learned weights)")
        sel = np.random.default_rng(SEED).choice(len(te), min(12, len(te)), replace=False)
        fig, ax = plt.subplots(len(sel), 3, figsize=(6, 2 * len(sel))); ax = np.atleast_2d(ax)
        for r_, j in enumerate(sel):
            om = object_mask(X[te[j]])
            ax[r_, 0].imshow(X[te[j]]); ax[r_, 0].set_title(f"{CLASSES[Y[te[j]]]} → {CLASSES[pc[j]]}", fontsize=7)
            ax[r_, 1].imshow(X[te[j]]); ax[r_, 1].imshow(cams[j], alpha=.45, cmap="jet"); ax[r_, 1].set_title("Grad-CAM", fontsize=7)
            ax[r_, 2].imshow(om if om is not None else np.zeros((224, 224)), cmap="gray"); ax[r_, 2].set_title("object mask", fontsize=7)
            for a in ax[r_]: a.axis("off")
        plt.tight_layout(); plt.savefig(f"{OUT}/figures/gradcam_with_object_mask_{BEST}.png", dpi=200); plt.close()
    del m, base, gm, cams; free_memory()
XA = pd.DataFrame(rows); XA.to_csv(f"{OUT}/tables/xai_per_image_{BEST}.csv", index=False)
ok = XA[XA.mask_ok]
summ = ok.groupby("cls").agg(n=("idx", "size"), object_area=("object_area", "mean"), cam_on_object=("cam_on_object", "mean"), pointing_hit=("pointing_hit", "mean"))
summ.loc["ALL"] = [len(ok), ok.object_area.mean(), ok.cam_on_object.mean(), ok.pointing_hit.mean()]
d = XA.dropna(subset=["deletion_auc"])
summ2 = pd.DataFrame(dict(n=[len(d)], deletion_auc=[d.deletion_auc.mean()], deletion_auc_random=[d.deletion_auc_random.mean()],
                          insertion_auc=[d.insertion_auc.mean()], insertion_auc_random=[d.insertion_auc_random.mean()]))
summ.to_csv(f"{OUT}/tables/xai_object_focus_{BEST}.csv"); summ2.to_csv(f"{OUT}/tables/xai_deletion_insertion_{BEST}.csv", index=False)
print("Masks usable:", int(XA.mask_ok.sum()), "of", len(XA)); display(summ.round(3)); display(summ2.round(3))
print("cam_on_object should be clearly ABOVE object_area; deletion AUC should be BELOW its random baseline, insertion AUC ABOVE.")

# %% Cell 12 — Make the expert rating sheet (early stage + severity + label check)
#@title Cell 12 — Make the expert rating sheet (early stage + severity + label check)
rng = np.random.default_rng(SEED)
dis = df[df.cls != "Healthy"].copy()
pick = []
for c, g in dis.groupby("cls"):
    n = len(g) if c == "Melanose" else (5 if SMOKE_TEST else 50)
    per_src = math.ceil(n / g.source.nunique())
    pick.append(g.groupby("source", group_keys=False).apply(lambda h: h.sample(min(len(h), per_src), random_state=SEED)).head(n))
sheet = pd.concat(pick).sample(frac=1, random_state=SEED).reset_index()
sheet["image_id"] = [f"IMG{i + 1:03d}" for i in range(len(sheet))]
for _, r in sheet.iterrows():
    Image.open(r.path).convert("RGB").save(f"{OUT}/expert/images/{r.image_id}.jpg", quality=95)
blank = pd.DataFrame(dict(image_id=sheet.image_id, disease_label=sheet.cls))
for col in ["label_correct", "stage", "severity", "comment"]: blank[col] = ""
blank.to_csv(f"{OUT}/expert/expert_rating_sheet_BLANK.csv", index=False)
sheet[["image_id", "index", "file", "cls", "source", "organ"]].to_csv(f"{OUT}/expert/expert_key_DO_NOT_SHARE.csv", index=False)
open(f"{OUT}/expert/INSTRUCTIONS.txt", "w").write(
"""For each image (open images/IMGxxx.jpg), fill one row. Work alone; do not discuss with the other expert.
label_correct: Yes / No / Unsure  — is the disease_label correct for this image?
stage: Early / Advanced / Unsure
   Early    = first visible symptoms: few, small, isolated lesions or spots; mild, localised yellowing; most of the leaf/fruit surface looks normal.
   Advanced = many or merging lesions, large necrotic or corky areas, widespread mottling/yellowing, or deformation.
severity: Mild / Moderate / Severe  (Mild <10%, Moderate 10-25%, Severe >25% of the visible surface affected; your best estimate)
comment: optional.
Save as ratings_expert1.csv (or ratings_expert2.csv) with the same columns.""")
print(len(sheet), "images exported for expert rating ->", f"{OUT}/expert/")

# %% Cell 13 — (run after the experts return their sheets) Stage-stratified results and agreement
#@title Cell 13 — (run after the experts return their sheets) Stage-stratified results and agreement
from sklearn.metrics import cohen_kappa_score
E1, E2 = f"{OUT}/expert/ratings_expert1.csv", f"{OUT}/expert/ratings_expert2.csv"
if os.path.exists(E1) and os.path.exists(E2):
    key = pd.read_csv(f"{OUT}/expert/expert_key_DO_NOT_SHARE.csv")
    norm = lambda s: s.astype(str).str.strip().str.lower()
    a, b = pd.read_csv(E1), pd.read_csv(E2)
    for t in (a, b):
        for col in ["label_correct", "stage", "severity"]: t[col] = norm(t[col])
    M = key.merge(a[["image_id", "label_correct", "stage", "severity"]], on="image_id").merge(
        b[["image_id", "label_correct", "stage", "severity"]], on="image_id", suffixes=("_e1", "_e2"))
    st = M[(M.stage_e1.isin(["early", "advanced"])) & (M.stage_e2.isin(["early", "advanced"]))]
    sv = {"mild": 0, "moderate": 1, "severe": 2}
    s2 = M[M.severity_e1.isin(sv) & M.severity_e2.isin(sv)]
    agree = dict(stage_kappa=cohen_kappa_score(st.stage_e1, st.stage_e2), stage_n=len(st),
                 severity_weighted_kappa=cohen_kappa_score(s2.severity_e1.map(sv), s2.severity_e2.map(sv), weights="quadratic"), severity_n=len(s2),
                 label_disputed=int(((M.label_correct_e1 == "no") | (M.label_correct_e2 == "no")).sum()), n=len(M))
    print(agree)
    M["stage"] = np.where((M.stage_e1 == M.stage_e2) & M.stage_e1.isin(["early", "advanced"]), M.stage_e1, "disputed")
    out = []
    for name in preds:
        M["correct"] = preds[name][M["index"].values] == Y[M["index"].values]
        for sname, g in M.groupby("stage"):
            c = int(g.correct.sum()); lo, hi = proportion_confint(c, len(g), method="wilson")
            out.append(dict(model=name, stage=sname, n=len(g), recall=c / len(g), ci95=f"{lo:.3f}-{hi:.3f}"))
    R_ = pd.DataFrame(out); R_.to_csv(f"{OUT}/tables/stage_stratified_recall.csv", index=False)
    pd.DataFrame([agree]).to_csv(f"{OUT}/tables/expert_agreement.csv", index=False); display(R_)
else:
    print("Expert sheets not found yet — skip this cell for now.")

# %% Cell 14 — Pack results (download both zips from the Output tab; weights are NOT included)
#@title Cell 14 — Pack results (download both zips from the Output tab; weights are NOT included)
pack = "/kaggle/temp/pack"
shutil.rmtree(pack, ignore_errors=True)
shutil.copytree(f"{OUT}/tables", f"{pack}/tables"); shutil.copytree(f"{OUT}/figures", f"{pack}/figures")
shutil.copy(f"{OUT}/expert/expert_rating_sheet_BLANK.csv", pack)
z = shutil.make_archive("/kaggle/working/citrus_v2_results" + ("_SMOKE" if SMOKE_TEST else "") + "_upload", "zip", pack)
print("Send me this file:", z)
# expert pack WITHOUT the answer key
ep = "/kaggle/temp/expert_pack"
shutil.rmtree(ep, ignore_errors=True)
shutil.copytree(f"{OUT}/expert", ep, ignore=shutil.ignore_patterns("expert_key_DO_NOT_SHARE.csv", "ratings_*.csv"))
z2 = shutil.make_archive("/kaggle/working/citrus_v2_expert_pack", "zip", ep)
print("Give this to the experts:", z2, "| keep expert_key_DO_NOT_SHARE.csv private")
