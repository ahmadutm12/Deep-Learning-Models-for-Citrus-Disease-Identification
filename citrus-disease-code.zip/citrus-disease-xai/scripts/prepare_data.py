"""Rebuild the pooled 1,834-image training collection (split_dataset/) from the original downloads.

The notebooks read the training images from a folder with the layout
    split_dataset/<old_split>/<class>/<file>
where <file> is the name given in data/manifest_training_images.csv.

This script finds every manifest image in the original downloads of
  * the Citrus Fruits and Leaves dataset of Rauf et al. (2019), Mendeley Data, doi:10.17632/3f83gxmv57.2
  * the Orange Diseases dataset of J. Cristovao (Kaggle: jonathansilva2020/orange-diseases-dataset)
first by SHA-256 checksum (exact copy) and, if no file has the same checksum, by its original folder and
file name. It copies the images into the layout above and writes a report.

Usage
    python scripts/prepare_data.py --rauf PATH_TO_RAUF_DOWNLOAD --orange PATH_TO_ORANGE_DISEASES_DOWNLOAD \
        --out split_dataset

Optionally, --emon PATH checks that the external test images of Emon et al. (2024), Mendeley Data,
doi:10.17632/f7cr74mwpj.1, are present (the notebooks read them directly from that download).
"""
import argparse
import csv
import hashlib
import os
import shutil
import sys
from collections import defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
MANIFEST = os.path.join(HERE, "..", "data", "manifest_training_images.csv")
EXT_MANIFEST = os.path.join(HERE, "..", "data", "manifest_external_images.csv")
IMG_EXT = (".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff")


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def index_folder(root):
    by_hash, by_name = {}, defaultdict(list)
    for d, _, files in os.walk(root):
        for f in files:
            if not f.lower().endswith(IMG_EXT):
                continue
            p = os.path.join(d, f)
            by_hash.setdefault(sha256(p), p)
            parent = os.path.basename(d).lower()
            by_name[(parent, f.lower())].append(p)
    return by_hash, by_name


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--rauf", required=True, help="folder of the extracted Rauf et al. download")
    ap.add_argument("--orange", required=True, help="folder of the extracted Orange Diseases download")
    ap.add_argument("--out", default="split_dataset", help="output folder (default: split_dataset)")
    ap.add_argument("--emon", default="", help="optional: folder of the extracted Emon et al. download")
    a = ap.parse_args()

    with open(MANIFEST, newline="", encoding="utf8") as f:
        rows = list(csv.DictReader(f))
    print(f"Manifest: {len(rows)} training images")

    idx = {}
    for key, root in [("Rauf2019_Sargodha", a.rauf), ("OrangeDiseases_Kaggle", a.orange)]:
        print(f"Indexing {root} ...")
        idx[key] = index_folder(root)

    n_hash = n_name = 0
    missing, changed = [], []
    for r in rows:
        by_hash, by_name = idx[r["source_dataset"]]
        src = by_hash.get(r["sha256"])
        if src:
            n_hash += 1
        else:
            parts = r["original_relative_path"].split("/")
            cands = by_name.get((parts[-2].lower(), parts[-1].lower()), [])
            if len(cands) == 1:
                src = cands[0]
                n_name += 1
                changed.append(r["file"])
            else:
                missing.append((r["file"], r["original_relative_path"], len(cands)))
                continue
        dst = os.path.join(a.out, r["old_split"], r["cls"], r["file"])
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        shutil.copy2(src, dst)

    print(f"Copied by checksum: {n_hash}; copied by folder and file name (bytes differ): {n_name}; "
          f"not found: {len(missing)}")
    with open("prepare_data_report.csv", "w", newline="", encoding="utf8") as f:
        w = csv.writer(f)
        w.writerow(["file", "status", "original_relative_path", "n_candidates"])
        for x in changed:
            w.writerow([x, "matched_by_name_bytes_differ", "", 1])
        for x, p, n in missing:
            w.writerow([x, "not_found", p, n])
    if changed:
        print("Some files differ byte-wise from the copies used in the paper; results may differ slightly.")
    if missing:
        print("Some images were not found; see prepare_data_report.csv.")

    if a.emon:
        with open(EXT_MANIFEST, newline="", encoding="utf8") as f:
            ext = list(csv.DictReader(f))
        present = set()
        for d, _, files in os.walk(a.emon):
            for fn in files:
                rel = os.path.relpath(os.path.join(d, fn), a.emon).replace(os.sep, "/")
                i = rel.find("Original Image/")
                if i >= 0:
                    present.add(rel[i:])
        n_ok = sum(r["relative_path"] in present for r in ext)
        print(f"External test images found: {n_ok} of {len(ext)}")

    return 0 if not missing else 1


if __name__ == "__main__":
    sys.exit(main())
