# Exported from notebooks/03_paper1_random_split_threshold_sensitivity_latency.ipynb (the notebook is the version that produced the published results).
# The code was written for Kaggle Notebooks (GPU T4); inputs are found under INPUT_ROOT, outputs go to OUT (Cell 1).
# Shell commands of the notebook are kept as comments; install the packages in requirements.txt first.
try:
    from IPython.display import display
except ImportError:
    display = print

# %% [markdown]
# # Citrus v4 — Paper 1 strengthening experiments (KAGGLE)
# 
# **What this notebook does** (earlier results are not changed; the grouped 5-fold benchmark is re-used as the reference):
# - **R** — random, *ungrouped* stratified 5-fold CV of ResNet50 and MobileNetV2 on all 1,834 images, compared image-by-image with the grouped benchmark (McNemar), with accuracy split by whether a test image has a near-duplicate in training.
# - **T** — grouping-threshold sensitivity: the near-duplicate audit is recomputed with the same method, groups are rebuilt at cosine 0.90 (looser) and 0.97 (stricter), and grouped 5-fold CV is repeated for both models.
# - **L** — CPU latency (batch 1) of all seven architectures.
# 
# **Inputs to add (right panel → Add Input):** (1) `citrus-data` dataset, (2) the output of notebook `notebook4b9b056063`.
# **Settings:** Accelerator **GPU T4 x2**, Internet **On**.
# **Check first:** run Cells 1–5 and send a screenshot of the outputs of Cells 2 and 4; then **Save Version → Save & Run All (Commit)** (about 4.5–5 h). Download **`citrus_v4_results_upload.zip`** from the Output tab.
# All long cells are resumable: if the run stops, attach this notebook's own output as an extra input and run again.

# %% Cell 1 — Settings   [notebook version 8.0 — Paper 1 experiments R, T, L, KAGGLE]
#@title Cell 1 — Settings   [notebook version 8.0 — Paper 1 experiments R, T, L, KAGGLE]
SEED = 42
INPUT_ROOT = "/kaggle/input"
OUT = "/kaggle/working/citrus_v4_results"
EXP_MODELS = ["ResNet50", "MobileNetV2"]
N_FOLDS = 5
HEAD_EP, FT_EP, FT_LAYERS, BATCH = 10, 8, 30, 32      # identical to the main benchmark
COS_T, PH_T, PH_COS = 0.95, 6, 0.85                   # main audit: near-duplicate if cosine >= COS_T, or (pHash <= PH_T and cosine >= PH_COS)
SENS_COS = [0.90, 0.97]                               # alternative cosine thresholds for the sensitivity analysis
LAT_MODELS = ["ResNet50", "MobileNetV2", "EfficientNetB0", "DenseNet121", "InceptionV3", "EfficientNetV2S", "ConvNeXtTiny"]
BR_P_KEEP, BR_P_COLOUR = 0.2, 0.4                     # only needed by a helper in Cell 5 (not used here)
import os
os.environ["CUDA_VISIBLE_DEVICES"] = "0"
os.environ["PYTHONHASHSEED"] = str(SEED)

# %% Cell 2 — Install, locate inputs, restore fold assignment and baseline predictions (from notebook v7.0)
#@title Cell 2 — Install, locate inputs, restore fold assignment and baseline predictions (from notebook v7.0)
# (shell) !pip -q install statsmodels scikit-image imagehash
import glob, zipfile, json, math, random, time, shutil
import numpy as np, pandas as pd
from PIL import Image
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
CLS_CHECK = ["Black_Spot", "Canker", "Greening", "Healthy", "Melanose"]

def is_data_root(d):
    return (os.path.isdir(f"{d}/train") and os.path.isdir(f"{d}/test")
            and sum(os.path.isdir(f"{d}/train/{c}") for c in CLS_CHECK) >= 3)
DATA = None
for root, dirs, files in os.walk(INPUT_ROOT):
    if is_data_root(root) and "SMOKE" not in root:
        DATA = root; break
if DATA is None:
    zips = glob.glob(f"{INPUT_ROOT}/**/split_dataset*.zip", recursive=True)
    assert zips, "split_dataset not found. add the Kaggle dataset that contains split_dataset (see DATA.md) via Add Input."
    with zipfile.ZipFile(zips[0]) as z:
        z.extractall("/kaggle/temp/data")
    for root, dirs, files in os.walk("/kaggle/temp/data"):
        if is_data_root(root):
            DATA = root; break
assert DATA
print("Images from:", DATA)
for sub in ["tables", "figures", "oof_prev", "oof_random", "oof_thr", "cache"]:
    os.makedirs(f"{OUT}/{sub}", exist_ok=True)
# resume: if the output of an earlier (stopped) run of THIS notebook is attached as input, restore its logs and predictions
for root, dirs, files in os.walk(INPUT_ROOT):
    if os.path.basename(root) == "citrus_v4_results" and os.path.isdir(f"{root}/tables"):
        for sub in ["tables", "oof_random", "oof_thr", "cache"]:
            if os.path.isdir(f"{root}/{sub}"):
                shutil.copytree(f"{root}/{sub}", f"{OUT}/{sub}", dirs_exist_ok=True)
        print("Resumed from earlier v4 output:", root)

# earlier results (only tables and out-of-fold predictions are copied; weights are not needed)
prev_dirs = []
for root, dirs, files in os.walk(INPUT_ROOT):
    if "SMOKE" in root or "citrus_v3" in root or "citrus_v4" in root:
        continue
    if os.path.isdir(f"{root}/tables") and os.path.isdir(f"{root}/oof"):
        prev_dirs.append(root)
FOLD_SRC = None
for p in prev_dirs:
    f = f"{p}/tables/images_groups_folds.csv"
    if FOLD_SRC is None and os.path.exists(f):
        FOLD_SRC = f
    for m in EXP_MODELS:
        for k in range(N_FOLDS):
            s, d = f"{p}/oof/{m}_fold{k}.npz", f"{OUT}/oof_prev/{m}_fold{k}.npz"
            if os.path.exists(s) and not os.path.exists(d):
                shutil.copy(s, d)
    for t in ["model_summary.csv", "cv_log.csv", "cross_source_ResNet50.csv"]:
        if os.path.exists(f"{p}/tables/{t}") and not os.path.exists(f"{OUT}/tables/prev_{t}"):
            shutil.copy(f"{p}/tables/{t}", f"{OUT}/tables/prev_{t}")
assert FOLD_SRC, "images_groups_folds.csv not found: add the output folder of notebook 01 (citrus_v2_results) via Add Input."
shutil.copy(FOLD_SRC, f"{OUT}/tables/images_groups_folds.csv")
print("Earlier results found in:", prev_dirs)
print("Baseline out-of-fold files restored:", sorted(os.listdir(f"{OUT}/oof_prev")))

import tensorflow as tf
import keras
from keras import layers
random.seed(SEED); np.random.seed(SEED); keras.utils.set_random_seed(SEED)
print("TF", tf.__version__, "| Keras", keras.__version__, "| GPU:", tf.config.list_physical_devices("GPU"))

# %% Cell 3 — Pool all 1,834 images and tag source / organ (unchanged)
#@title Cell 3 — Pool all 1,834 images and tag source / organ (unchanged)
CLASSES = ["Black_Spot", "Canker", "Greening", "Healthy", "Melanose"]
NC = len(CLASSES)
rows = []
for split in ["train", "val", "test"]:
    for c in CLASSES:
        for f in sorted(glob.glob(f"{DATA}/{split}/{c}/*")):
            b = os.path.basename(f)
            src = "Rauf" if b.startswith("citrus_") else ("Silva" if b.startswith("archive1_") else "Other")
            organ = "leaf" if (src == "Rauf" and "Leaves" in b) else "fruit"
            rows.append(dict(path=f, file=b, cls=c, y=CLASSES.index(c), source=src, organ=organ, old_split=split))
df = pd.DataFrame(rows)
N = len(df)
print(N, "images")
display(pd.crosstab([df.source, df.organ], df.cls, margins=True))

def load(p, size=224):
    return np.asarray(Image.open(p).convert("RGB").resize((size, size), Image.BILINEAR), dtype=np.uint8)
X = np.stack([load(p) for p in df.path])
Y = df.y.values.astype("int64")

# %% Cell 4 — Re-use the grouped, stratified 5-fold split of the main benchmark
#@title Cell 4 — Re-use the grouped, stratified 5-fold split of the main benchmark
from sklearn.model_selection import StratifiedGroupKFold
FOLD_CSV = f"{OUT}/tables/images_groups_folds.csv"
reused = False
if os.path.exists(FOLD_CSV):
    prev = pd.read_csv(FOLD_CSV)
    kp = prev.old_split + "|" + prev.cls + "|" + prev.file
    kd = df.old_split + "|" + df.cls + "|" + df.file
    if len(prev) == N and kd.isin(set(kp)).all():
        df["group"] = kd.map(dict(zip(kp, prev.group))).values
        df["fold"] = kd.map(dict(zip(kp, prev.fold))).values.astype(int)
        reused = True
        print("Re-using the group and fold assignment saved by the earlier run (finished folds stay valid).")
assert reused, "The fold file of the main benchmark was not matched; do not continue."
G = df.group.values
if not reused:
    sgkf = StratifiedGroupKFold(n_splits=N_FOLDS, shuffle=True, random_state=SEED)
    df["fold"] = -1
    for k, (_, te) in enumerate(sgkf.split(np.zeros(N), Y, G)):
        df.loc[te, "fold"] = k
display(pd.crosstab(df.fold, df.cls))

def split_fold(k):
    te = np.where(df.fold.values == k)[0]
    rest = np.where(df.fold.values != k)[0]
    inner = StratifiedGroupKFold(n_splits=6, shuffle=True, random_state=SEED + k)
    tr_i, va_i = next(inner.split(np.zeros(len(rest)), Y[rest], G[rest]))
    return rest[tr_i], rest[va_i], te
for k in range(N_FOLDS):
    tr, va, te = split_fold(k)
    assert not (set(G[tr]) & set(G[te])) and not (set(G[va]) & set(G[te])) and not (set(G[tr]) & set(G[va]))
print("Check passed: no near-duplicate group is shared between train, validation and test in any fold.")
df.drop(columns=["path"]).to_csv(f"{OUT}/tables/images_groups_folds.csv", index=False)

# %% Cell 5 — Models, data pipeline, training helpers, object masks and background randomisation
#@title Cell 5 — Models, data pipeline, training helpers, object masks and background randomisation
APPS = {
    "ResNet50": (keras.applications.ResNet50, keras.applications.resnet.preprocess_input),
    "MobileNetV2": (keras.applications.MobileNetV2, keras.applications.mobilenet_v2.preprocess_input),
    "EfficientNetB0": (keras.applications.EfficientNetB0, keras.applications.efficientnet.preprocess_input),
    "DenseNet121": (keras.applications.DenseNet121, keras.applications.densenet.preprocess_input),
    "InceptionV3": (keras.applications.InceptionV3, keras.applications.inception_v3.preprocess_input),
    "EfficientNetV2S": (keras.applications.EfficientNetV2S, keras.applications.efficientnet_v2.preprocess_input),
    "ConvNeXtTiny": (keras.applications.ConvNeXtTiny, keras.applications.convnext.preprocess_input),
}
AUTOTUNE = tf.data.AUTOTUNE
AUG = keras.Sequential([layers.RandomFlip("horizontal_and_vertical"), layers.RandomRotation(0.1), layers.RandomZoom(0.2),
                        layers.RandomContrast(0.2), layers.RandomBrightness(0.2, value_range=(0, 255))])

def build_model(name, n_out):
    ctor, _ = APPS[name]
    inp = keras.Input((224, 224, 3))
    base = ctor(include_top=False, weights="imagenet", input_tensor=inp)
    x = layers.GlobalAveragePooling2D()(base.output)
    x = layers.Dropout(0.3)(x)
    out = layers.Dense(n_out, activation="softmax", dtype="float32")(x)
    return keras.Model(inp, out), base

def _batch_index(ya, seed, n_batches):
    """Square-root class-balanced sampling with replacement (same rule as before), as a fixed index table."""
    rng = np.random.default_rng(seed)
    cls = np.unique(ya); idx = [np.where(ya == c)[0] for c in cls]
    w = np.sqrt([len(i) for i in idx]); w = w / w.sum()
    out = np.empty((n_batches, BATCH), dtype="int64")
    for b in range(n_batches):
        cs = rng.choice(len(cls), size=BATCH, p=w)
        out[b] = [rng.choice(idx[c]) for c in cs]
    return out

def train_ds(Xa, ya, prep):
    with tf.device("/CPU:0"):
        Xt = tf.convert_to_tensor(Xa); yt = tf.convert_to_tensor(np.asarray(ya, dtype="int64"))
    steps = max(1, math.ceil(len(ya) / BATCH))
    ds = tf.data.Dataset.from_tensor_slices(_batch_index(np.asarray(ya), SEED, steps * max(HEAD_EP, FT_EP))).repeat()
    ds = ds.map(lambda i: (tf.gather(Xt, i), tf.gather(yt, i)))
    return ds.map(lambda x, y: (prep(AUG(tf.cast(x, tf.float32), training=True)), y), num_parallel_calls=AUTOTUNE).prefetch(2)

def eval_ds(Xa, prep, ya=None, fn=None):
    if fn is not None:
        Xa = np.stack([fn(x) for x in Xa])
    if ya is None:
        return tf.data.Dataset.from_tensor_slices(Xa).batch(BATCH).map(lambda x: prep(tf.cast(x, tf.float32))).prefetch(2)
    ds = tf.data.Dataset.from_tensor_slices((Xa, np.asarray(ya, dtype="int64"))).batch(BATCH)
    return ds.map(lambda x, y: (prep(tf.cast(x, tf.float32)), y)).prefetch(2)

def ram_gb():
    try:
        import psutil; return psutil.Process().memory_info().rss / 1e9
    except Exception:
        return float("nan")
def ram_limit_gb():
    try:
        import psutil; return 0.75 * psutil.virtual_memory().total / 1e9
    except Exception:
        return 1e9

def free_memory(*objs):
    import gc
    for o in objs: del o
    keras.backend.clear_session(); gc.collect(); gc.collect()

def train_one(name, Xtr, ytr, Xva, yva, n_out):
    keras.backend.clear_session(); keras.utils.set_random_seed(SEED)
    model, base = build_model(name, n_out)
    prep = APPS[name][1]
    tr, va = train_ds(Xtr, ytr, prep), eval_ds(Xva, prep, yva)
    steps = max(1, math.ceil(len(ytr) / BATCH))
    loss = "sparse_categorical_crossentropy"
    for l in base.layers: l.trainable = False
    model.compile(optimizer=keras.optimizers.Adam(1e-3), loss=loss, metrics=["accuracy"])
    model.fit(tr, validation_data=va, epochs=HEAD_EP, steps_per_epoch=steps, verbose=0,
              callbacks=[keras.callbacks.EarlyStopping(monitor="val_loss", patience=3, restore_best_weights=True)])
    for l in base.layers[-FT_LAYERS:]:
        if not isinstance(l, layers.BatchNormalization): l.trainable = True
    model.compile(optimizer=keras.optimizers.Adam(1e-5), loss=loss, metrics=["accuracy"])
    model.fit(tr, validation_data=va, epochs=FT_EP, steps_per_epoch=steps, verbose=0,
              callbacks=[keras.callbacks.EarlyStopping(monitor="val_loss", patience=3, restore_best_weights=True)])
    return model, base

def predict_u8(model, name, Xa, fn=None):
    return model.predict(eval_ds(Xa, APPS[name][1], fn=fn), verbose=0)

def centre_only(x, keep=0.7):
    h = x.shape[0]; m = int(h * (1 - keep) / 2)
    out = np.full_like(x, 124); out[m:h - m, m:h - m] = x[m:h - m, m:h - m]; return out
def corners_only(x, s=56):
    h = x.shape[0]; out = np.full_like(x, 124)
    for r, c in [(0, 0), (0, h - s), (h - s, 0), (h - s, h - s)]:
        out[r:r + s, c:c + s] = x[r:r + s, c:c + s]
    return out

from scipy import ndimage as ndi
from skimage import color, filters, measure
from sklearn.metrics import f1_score, accuracy_score, confusion_matrix
from sklearn.model_selection import StratifiedGroupKFold
from statsmodels.stats.proportion import proportion_confint
from statsmodels.stats.contingency_tables import mcnemar
def object_mask(x):
    """Leaf/fruit mask on plain backgrounds. Black padding or black backdrops are treated as background.
    Returns None when the mask is unreliable (cluttered field scenes, fragmented or tiny/huge masks)."""
    fill = x.max(axis=-1) < 25
    lab = color.rgb2lab(x)
    ring = np.zeros(x.shape[:2], bool); ring[:8] = ring[-8:] = True; ring[:, :8] = ring[:, -8:] = True
    bsel = ring & ~fill
    if bsel.sum() < 0.25 * ring.sum():          # border is mostly black: dark backdrop or padding
        m = ndi.binary_opening(x.max(axis=-1) >= 40, structure=np.ones((5, 5)))
    else:
        d = np.linalg.norm(lab - np.median(lab[bsel], 0), axis=-1); d[fill] = 0
        if (~fill).sum() < 100 or np.ptp(d[~fill]) == 0: return None
        m = ndi.binary_opening(d > filters.threshold_otsu(d[~fill]), structure=np.ones((5, 5))) & ~fill
    lbl = measure.label(m)
    if lbl.max() == 0: return None
    h = x.shape[0]; c0, c1 = h // 4, 3 * h // 4
    centre = np.bincount(lbl[c0:c1, c0:c1].ravel(), minlength=lbl.max() + 1)[1:]
    if centre.max() == 0: return None
    m = ndi.binary_fill_holes(lbl == (int(np.argmax(centre)) + 1))
    if not (0.05 < m.mean() < 0.95): return None
    if measure.regionprops(m.astype(np.uint8))[0].solidity < 0.6: return None   # fragmented -> unreliable
    return m

def randomise_background(x, m):
    """x: float32 batch (0-255), m: float32 masks (1 = leaf/fruit). Keeps the object, replaces the background
    by a random colour or a smooth random texture; images without a reliable mask have m = 1 everywhere."""
    b = tf.shape(x)[0]
    colour = tf.random.uniform((b, 1, 1, 3), 0.0, 255.0) * tf.ones_like(x)
    tex = tf.image.resize(tf.random.uniform((b, 28, 28, 3), 0.0, 255.0), (224, 224), method="bicubic")
    tex = tf.clip_by_value(tf.nn.avg_pool2d(tex, 9, 1, "SAME"), 0.0, 255.0)
    u = tf.random.uniform((b, 1, 1, 1))
    bg = tf.where(u < BR_P_KEEP + BR_P_COLOUR, colour, tex)
    return tf.where(u < BR_P_KEEP, x, m * x + (1.0 - m) * bg)

def train_ds2(Xa, ya, prep, seed, Ma=None):
    with tf.device("/CPU:0"):
        Xt = tf.convert_to_tensor(Xa); yt = tf.convert_to_tensor(np.asarray(ya, dtype="int64"))
        Mt = None if Ma is None else tf.convert_to_tensor(Ma[..., None])
    steps = max(1, math.ceil(len(ya) / BATCH))
    ds = tf.data.Dataset.from_tensor_slices(_batch_index(np.asarray(ya), seed, steps * max(HEAD_EP, FT_EP))).repeat()
    if Mt is None:
        ds = ds.map(lambda i: (tf.gather(Xt, i), tf.gather(yt, i)))
        return ds.map(lambda x, y: (prep(AUG(tf.cast(x, tf.float32), training=True)), y), num_parallel_calls=AUTOTUNE).prefetch(2)
    ds = ds.map(lambda i: (tf.gather(Xt, i), tf.gather(Mt, i), tf.gather(yt, i)))
    return ds.map(lambda x, m, y: (prep(AUG(randomise_background(tf.cast(x, tf.float32), tf.cast(m, tf.float32)), training=True)), y),
                  num_parallel_calls=AUTOTUNE).prefetch(2)

def train_two(name, Xtr, ytr, Xva, yva, n_out, Mtr=None, seed=SEED):
    """Same two-stage recipe as the main benchmark; Mtr=None gives the baseline, masks give background randomisation."""
    keras.backend.clear_session(); keras.utils.set_random_seed(seed)
    model, base = build_model(name, n_out)
    prep = APPS[name][1]
    tr, va = train_ds2(Xtr, ytr, prep, seed, Mtr), eval_ds(Xva, prep, yva)
    steps = max(1, math.ceil(len(ytr) / BATCH))
    loss = "sparse_categorical_crossentropy"
    for l in base.layers: l.trainable = False
    model.compile(optimizer=keras.optimizers.Adam(1e-3), loss=loss, metrics=["accuracy"])
    model.fit(tr, validation_data=va, epochs=HEAD_EP, steps_per_epoch=steps, verbose=0,
              callbacks=[keras.callbacks.EarlyStopping(monitor="val_loss", patience=3, restore_best_weights=True)])
    for l in base.layers[-FT_LAYERS:]:
        if not isinstance(l, layers.BatchNormalization): l.trainable = True
    model.compile(optimizer=keras.optimizers.Adam(1e-5), loss=loss, metrics=["accuracy"])
    model.fit(tr, validation_data=va, epochs=FT_EP, steps_per_epoch=steps, verbose=0,
              callbacks=[keras.callbacks.EarlyStopping(monitor="val_loss", patience=3, restore_best_weights=True)])
    return model, base

def mf1(y, p, labels=None):
    return f1_score(y, p, average="macro", labels=labels if labels is not None else np.unique(y), zero_division=0)
def wilson(c, n):
    lo, hi = proportion_confint(c, n, method="wilson"); return f"{lo:.3f}-{hi:.3f}"
def append_log(path, row):
    L = pd.read_csv(path) if os.path.exists(path) else pd.DataFrame()
    pd.concat([L, pd.DataFrame([row])], ignore_index=True).to_csv(path, index=False)

# %% Cell 6 — Experiment R: random (ungrouped) stratified 5-fold CV (resumable)
#@title Cell 6 — Experiment R: random (ungrouped) stratified 5-fold CV (resumable)
from sklearn.model_selection import StratifiedKFold
skf = StratifiedKFold(n_splits=N_FOLDS, shuffle=True, random_state=SEED)
RFOLD = np.full(N, -1)
for k, (_, te) in enumerate(skf.split(np.zeros(N), Y)):
    RFOLD[te] = k
pd.DataFrame({"file": df.file, "cls": df.cls, "random_fold": RFOLD}).to_csv(f"{OUT}/tables/random_folds.csv", index=False)

def split_random(k):
    te = np.where(RFOLD == k)[0]; rest = np.where(RFOLD != k)[0]
    inner = StratifiedKFold(n_splits=6, shuffle=True, random_state=SEED + k)
    tr_i, va_i = next(inner.split(np.zeros(len(rest)), Y[rest]))
    return rest[tr_i], rest[va_i], te

LOG_R = f"{OUT}/tables/random_cv_log.csv"
for name in EXP_MODELS:
    for k in range(N_FOLDS):
        L = pd.read_csv(LOG_R) if os.path.exists(LOG_R) else pd.DataFrame(columns=["model", "fold"])
        if ((L.model == name) & (L.fold == k)).any():
            print("skip (already done):", name, k); continue
        t0 = time.time()
        tr, va, te = split_random(k)
        leaky = np.isin(G[te], G[np.concatenate([tr, va])])     # test image shares a near-duplicate group (main audit) with a training/validation image
        model, base = train_two(name, X[tr], Y[tr], X[va], Y[va], NC, Mtr=None, seed=SEED)
        p = predict_u8(model, name, X[te]); pr = p.argmax(1); yt = Y[te]
        np.savez_compressed(f"{OUT}/oof_random/{name}_fold{k}.npz", te=te, p_full=p, leaky=leaky)
        row = dict(model=name, fold=k, n_test=len(te), acc=accuracy_score(yt, pr), macro_f1=mf1(yt, pr), frac_leaky=float(leaky.mean()),
                   acc_leaky=float((pr[leaky] == yt[leaky]).mean()) if leaky.any() else np.nan,
                   acc_nonleaky=float((pr[~leaky] == yt[~leaky]).mean()) if (~leaky).any() else np.nan, minutes=(time.time() - t0) / 60)
        append_log(LOG_R, row)
        print({a: (round(b, 3) if isinstance(b, float) else b) for a, b in row.items()})
        del model, base; free_memory()

# %% Cell 7 — Recompute the near-duplicate similarity (same method as the main audit) and build alternative groupings
#@title Cell 7 — Recompute the near-duplicate similarity (same method as the main audit) and build alternative groupings
import imagehash
from sklearn.metrics import adjusted_rand_score
FEAT = f"{OUT}/cache/dup_features.npz"
if os.path.exists(FEAT):
    zf = np.load(FEAT); PH, COS = zf["PH"], zf["COS"]
    print("Loaded cached similarity matrices.")
else:
    def dihedral(im):
        out = []
        for r_ in range(4):
            r = im.rotate(90 * r_)
            out += [r, r.transpose(Image.FLIP_LEFT_RIGHT)]
        return out
    H = np.zeros((N, 8), dtype=np.uint64)
    for i in range(N):
        for t, v in enumerate(dihedral(Image.fromarray(X[i]))):
            H[i, t] = np.uint64(int(str(imagehash.phash(v)), 16))
    def popcount64(a):
        return np.unpackbits(np.ascontiguousarray(a).view(np.uint8).reshape(a.shape + (8,)), axis=-1).sum(-1)
    PH = np.full((N, N), 64, dtype=np.uint8)
    for t in range(8):
        for s in range(0, N, 128):
            PH[s:s + 128] = np.minimum(PH[s:s + 128], popcount64(H[s:s + 128, 0][:, None] ^ H[None, :, t]))
    emb = keras.applications.EfficientNetB0(include_top=False, pooling="avg", weights="imagenet")
    E = np.zeros((N, int(emb.outputs[0].shape[-1])), dtype="float32")
    for s in range(0, N, 128):
        xb = X[s:s + 128]; f = 0
        for r_ in range(4):
            f = f + emb.predict(keras.applications.efficientnet.preprocess_input(np.rot90(xb, r_, axes=(1, 2)).astype("float32")), verbose=0)
        E[s:s + 128] = f / 4
    E /= np.linalg.norm(E, axis=1, keepdims=True)
    COS = (E @ E.T).astype("float32")
    np.savez_compressed(FEAT, PH=PH, COS=COS)
    del emb, E, H; free_memory()

def make_groups(cos_t):
    same = Y[:, None] == Y[None, :]
    near = (COS >= cos_t) | ((PH <= PH_T) & (COS >= PH_COS))
    np.fill_diagonal(near, False)
    parent = list(range(N))
    def find(a):
        while parent[a] != a:
            parent[a] = parent[parent[a]]; a = parent[a]
        return a
    for i, j in zip(*np.where(np.triu(near & same))):
        ri, rj = find(i), find(j)
        if ri != rj: parent[ri] = rj
    return np.array([find(i) for i in range(N)])

G95 = make_groups(COS_T)
print(f"Recomputed main grouping (cosine {COS_T}) vs the saved grouping: adjusted Rand index = {adjusted_rand_score(G, G95):.4f}")
GROUPINGS = {t: make_groups(t) for t in SENS_COS}
rows = []
for t, g in [(COS_T, G)] + list(GROUPINGS.items()):
    gs = pd.Series(g).value_counts()
    rows.append(dict(cos_threshold=t, groups_size_gt1=int((gs > 1).sum()), images_in_groups=int(gs[gs > 1].sum()),
                     largest_group=int(gs.max()), independent_units=int(len(gs))))
GS = pd.DataFrame(rows); GS.to_csv(f"{OUT}/tables/grouping_summary.csv", index=False); display(GS)

FOLDS_T = {}
for t, g in GROUPINGS.items():
    sg = StratifiedGroupKFold(n_splits=N_FOLDS, shuffle=True, random_state=SEED)
    f = np.full(N, -1)
    for k, (_, te) in enumerate(sg.split(np.zeros(N), Y, g)):
        f[te] = k
    FOLDS_T[t] = f
    print(f"cosine {t}: test-fold sizes", np.bincount(f, minlength=N_FOLDS).tolist())
alt = pd.DataFrame({"file": df.file, "cls": df.cls})
for t in SENS_COS:
    alt[f"group_cos{t}"] = GROUPINGS[t]; alt[f"fold_cos{t}"] = FOLDS_T[t]
alt.to_csv(f"{OUT}/tables/alt_groupings_folds.csv", index=False)

# %% Cell 8 — Experiment T: grouped 5-fold CV at the alternative thresholds (resumable)
#@title Cell 8 — Experiment T: grouped 5-fold CV at the alternative thresholds (resumable)
def split_alt(t, k):
    g, f = GROUPINGS[t], FOLDS_T[t]
    te = np.where(f == k)[0]; rest = np.where(f != k)[0]
    inner = StratifiedGroupKFold(n_splits=6, shuffle=True, random_state=SEED + k)
    tr_i, va_i = next(inner.split(np.zeros(len(rest)), Y[rest], g[rest]))
    tr, va = rest[tr_i], rest[va_i]
    assert not (set(g[tr]) & set(g[te])) and not (set(g[va]) & set(g[te])) and not (set(g[tr]) & set(g[va]))
    return tr, va, te

LOG_T = f"{OUT}/tables/threshold_cv_log.csv"
for t in SENS_COS:
    for name in EXP_MODELS:
        for k in range(N_FOLDS):
            L = pd.read_csv(LOG_T) if os.path.exists(LOG_T) else pd.DataFrame(columns=["cos_threshold", "model", "fold"])
            if ((np.isclose(L.cos_threshold.astype(float), t)) & (L.model == name) & (L.fold == k)).any():
                print("skip (already done):", t, name, k); continue
            t0 = time.time()
            tr, va, te = split_alt(t, k)
            leaky95 = np.isin(G[te], G[np.concatenate([tr, va])])   # residual leakage judged by the main (0.95) grouping
            model, base = train_two(name, X[tr], Y[tr], X[va], Y[va], NC, Mtr=None, seed=SEED)
            p = predict_u8(model, name, X[te]); pr = p.argmax(1); yt = Y[te]
            np.savez_compressed(f"{OUT}/oof_thr/{name}_cos{t}_fold{k}.npz", te=te, p_full=p, leaky95=leaky95)
            row = dict(cos_threshold=t, model=name, fold=k, n_test=len(te), acc=accuracy_score(yt, pr), macro_f1=mf1(yt, pr),
                       frac_leaky95=float(leaky95.mean()), minutes=(time.time() - t0) / 60)
            append_log(LOG_T, row)
            print({a: (round(b, 3) if isinstance(b, float) else b) for a, b in row.items()})
            del model, base; free_memory()

# %% Cell 9 — Experiment L: CPU latency of all seven architectures (batch 1, 224 x 224)
#@title Cell 9 — Experiment L: CPU latency of all seven architectures (batch 1, 224 x 224)
import subprocess
LAT = f"{OUT}/tables/cpu_latency.csv"
if not os.path.exists(LAT):
    cpu = subprocess.run("lscpu | grep 'Model name'", shell=True, capture_output=True, text=True).stdout.strip()
    rows = []
    for name in LAT_MODELS:
        keras.backend.clear_session()
        with tf.device("/CPU:0"):
            model, base = build_model(name, NC)
            x1 = APPS[name][1](np.random.default_rng(0).integers(0, 255, (1, 224, 224, 3)).astype("float32"))
            fwd = tf.function(lambda x: model(x, training=False))
            for _ in range(10): fwd(x1)
            ts = []
            for _ in range(50):
                t0 = time.perf_counter(); _ = fwd(x1).numpy(); ts.append(1000 * (time.perf_counter() - t0))
        rows.append(dict(model=name, params_M=model.count_params() / 1e6, cpu_ms_median=float(np.median(ts)),
                         cpu_ms_p95=float(np.percentile(ts, 95)), cpu=cpu, logical_cpus=os.cpu_count()))
        print(rows[-1]); del model, base; free_memory()
    pd.DataFrame(rows).to_csv(LAT, index=False)
display(pd.read_csv(LAT).round(2))

# %% Cell 10 — Summary tables for Paper 1
#@title Cell 10 — Summary tables for Paper 1
def gather(pattern):
    P, extra = {}, {}
    for k in range(N_FOLDS):
        a = np.load(pattern.format(k=k))
        for j, i in enumerate(a["te"]):
            P[int(i)] = int(a["p_full"][j].argmax())
            for key in [kk for kk in a.files if kk.startswith("leaky")]:
                extra.setdefault(key, {})[int(i)] = bool(a[key][j])
    idx = np.array(sorted(P)); assert len(idx) == N
    return np.array([P[i] for i in idx]), {k: np.array([v[i] for i in idx]) for k, v in extra.items()}
def mcn(c0, c1):
    return mcnemar([[int((c0 & c1).sum()), int((c0 & ~c1).sum())], [int((~c0 & c1).sum()), int((~c0 & ~c1).sum())]], exact=True).pvalue
y = Y
rows_r, rows_t = [], []
for name in EXP_MODELS:
    pg, _ = gather(f"{OUT}/oof_prev/{name}_fold{{k}}.npz")
    cg = pg == y
    base = dict(model=name, n=N, acc=cg.mean(), acc_ci95=wilson(int(cg.sum()), N), macro_f1=mf1(y, pg))
    rows_r.append(dict(protocol="grouped (main benchmark)", **base))
    rows_t.append(dict(cos_threshold=COS_T, frac_test_with_dup95_in_train=0.0, mcnemar_p_vs_cos095=np.nan, **base))
    if all(os.path.exists(f"{OUT}/oof_random/{name}_fold{k}.npz") for k in range(N_FOLDS)):
        pr, ex = gather(f"{OUT}/oof_random/{name}_fold{{k}}.npz"); cr = pr == y; lk = ex["leaky"]
        rows_r.append(dict(protocol="random (ungrouped)", model=name, n=N, acc=cr.mean(), acc_ci95=wilson(int(cr.sum()), N), macro_f1=mf1(y, pr),
                           mcnemar_p_vs_grouped=mcn(cg, cr), frac_test_with_dup_in_train=lk.mean(),
                           acc_test_with_dup=cr[lk].mean(), acc_test_without_dup=cr[~lk].mean(),
                           grouped_acc_same_images_with_dup=cg[lk].mean(), grouped_acc_same_images_without_dup=cg[~lk].mean()))
    for t in SENS_COS:
        if all(os.path.exists(f"{OUT}/oof_thr/{name}_cos{t}_fold{k}.npz") for k in range(N_FOLDS)):
            pt, ex = gather(f"{OUT}/oof_thr/{name}_cos{t}_fold{{k}}.npz"); ct = pt == y
            rows_t.append(dict(cos_threshold=t, model=name, n=N, acc=ct.mean(), acc_ci95=wilson(int(ct.sum()), N), macro_f1=mf1(y, pt),
                               frac_test_with_dup95_in_train=ex["leaky95"].mean(), mcnemar_p_vs_cos095=mcn(cg, ct)))
R_ = pd.DataFrame(rows_r); R_.to_csv(f"{OUT}/tables/R_random_vs_grouped.csv", index=False); display(R_.round(3))
T_ = pd.DataFrame(rows_t).merge(GS, on="cos_threshold", how="left"); T_.to_csv(f"{OUT}/tables/T_threshold_sensitivity.csv", index=False); display(T_.round(3))

# %% Cell 11 — Pack results (send citrus_v4_results_upload.zip)
#@title Cell 11 — Pack results (send citrus_v4_results_upload.zip)
pack = "/kaggle/temp/pack_v4"
shutil.rmtree(pack, ignore_errors=True)
shutil.copytree(f"{OUT}/tables", f"{pack}/tables"); shutil.copytree(f"{OUT}/figures", f"{pack}/figures")
z = shutil.make_archive("/kaggle/working/citrus_v4_results_upload", "zip", pack)
print("Send me this file:", z)
