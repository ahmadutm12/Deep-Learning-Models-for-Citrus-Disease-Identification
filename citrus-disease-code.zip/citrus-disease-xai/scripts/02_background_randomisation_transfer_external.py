# Exported from notebooks/02_background_randomisation_transfer_external.ipynb (the notebook is the version that produced the published results).
# The code was written for Kaggle Notebooks (GPU T4); inputs are found under INPUT_ROOT, outputs go to OUT (Cell 1).
# Shell commands of the notebook are kept as comments; install the packages in requirements.txt first.
try:
    from IPython.display import display
except ImportError:
    display = print

# %% [markdown]
# # Citrus v3 — Experiments A + B (KAGGLE): background-robust training and external sweet-orange test
# 
# **What this notebook does** (no earlier result is changed):
# - **A1** — background-randomised training (leaf/fruit kept, background replaced by random colour or texture) for MobileNetV2 and ResNet50 under the *same* grouped 5-fold split; shortcut tests (corners only / centre only) and grey-background test.
# - **A2** — cross-dataset transfer (Orange Diseases → Sargodha, Sargodha → Orange Diseases), baseline vs background-randomised, 3 seeds.
# - **B** — external test on the independent sweet-orange leaf dataset of Emon et al. (Mendeley Data 10.17632/f7cr74mwpj.1): Canker, Greening and Healthy leaves only; models trained on all 1,834 images, baseline vs background-randomised, 3 seeds.
# 
# **Inputs to add (right panel → Add Input):** (1) `citrus-data` dataset, (2) output of notebook `notebook4b9b056063` (or `notebook152fe2c903`), (3) your uploaded Emon sweet-orange dataset.
# **Settings:** Accelerator **GPU T4 x2**, Internet **On**.
# **Check first:** run Cells 1–6 only and send a screenshot of the outputs of Cells 2, 6 and 9's first lines; then **Save Version → Save & Run All (Commit)** (≈4–5 h). Download **`citrus_v3_results_upload.zip`** from the Output tab.
# All long cells are resumable: if the run stops, attach this notebook's own output as an extra input and run again.

# %% Cell 1 — Settings   [notebook version 7.0 — experiments A+B, KAGGLE]
#@title Cell 1 — Settings   [notebook version 7.0 — experiments A+B, KAGGLE]
SEED = 42
INPUT_ROOT = "/kaggle/input"
OUT = "/kaggle/working/citrus_v3_results"
EXP_MODELS = ["MobileNetV2", "ResNet50"]
N_FOLDS = 5
HEAD_EP, FT_EP, FT_LAYERS, BATCH = 10, 8, 30, 32      # identical to the main benchmark
SEEDS = [0, 1, 2]                                       # seeds for transfer and external experiments
BR_P_KEEP, BR_P_COLOUR = 0.2, 0.4                       # per image: keep 20%, random colour 40%, random texture 40%
EXTERNAL_DIR = ""                                       # leave empty: the Emon dataset is found automatically under /kaggle/input
EXT_CLASS_MAP = {"canker": "Canker", "greening": "Greening", "healthy": "Healthy"}
EXT_EXCLUDE = ["yellow dragon", "yellow_dragon", "augment"]
import os
os.environ["CUDA_VISIBLE_DEVICES"] = "0"
os.environ["PYTHONHASHSEED"] = str(SEED)

# %% Cell 2 — Install, locate inputs, restore fold assignment and baseline predictions
#@title Cell 2 — Install, locate inputs, restore fold assignment and baseline predictions
# (shell) !pip -q install statsmodels scikit-image
import glob, zipfile, json, math, random, time, shutil
import numpy as np, pandas as pd
from PIL import Image
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
CLS_CHECK = ["Black_Spot", "Canker", "Greening", "Healthy", "Melanose"]

def is_data_root(d):
    return (os.path.isdir(f"{d}/train") and os.path.isdir(f"{d}/test")
            and sum(os.path.isdir(f"{d}/train/{c}") for c in CLS_CHECK) >= 3)
DATA = None
for root, dirs, files in os.walk(INPUT_ROOT):
    if is_data_root(root) and "SMOKE" not in root:
        DATA = root; break
if DATA is None:
    zips = glob.glob(f"{INPUT_ROOT}/**/split_dataset*.zip", recursive=True)
    assert zips, "split_dataset not found. add the Kaggle dataset that contains split_dataset (see DATA.md) via Add Input."
    with zipfile.ZipFile(zips[0]) as z:
        z.extractall("/kaggle/temp/data")
    for root, dirs, files in os.walk("/kaggle/temp/data"):
        if is_data_root(root):
            DATA = root; break
assert DATA
print("Images from:", DATA)
for sub in ["tables", "figures", "oof_br", "oof_prev", "preds"]:
    os.makedirs(f"{OUT}/{sub}", exist_ok=True)

# earlier results (only tables and out-of-fold predictions are copied; weights are not needed)
prev_dirs = []
for root, dirs, files in os.walk(INPUT_ROOT):
    if "SMOKE" in root or "citrus_v3" in root:
        continue
    if os.path.isdir(f"{root}/tables") and os.path.isdir(f"{root}/oof"):
        prev_dirs.append(root)
FOLD_SRC = None
for p in prev_dirs:
    f = f"{p}/tables/images_groups_folds.csv"
    if FOLD_SRC is None and os.path.exists(f):
        FOLD_SRC = f
    for m in EXP_MODELS:
        for k in range(N_FOLDS):
            s, d = f"{p}/oof/{m}_fold{k}.npz", f"{OUT}/oof_prev/{m}_fold{k}.npz"
            if os.path.exists(s) and not os.path.exists(d):
                shutil.copy(s, d)
    for t in ["model_summary.csv", "cv_log.csv", "cross_source_ResNet50.csv"]:
        if os.path.exists(f"{p}/tables/{t}") and not os.path.exists(f"{OUT}/tables/prev_{t}"):
            shutil.copy(f"{p}/tables/{t}", f"{OUT}/tables/prev_{t}")
assert FOLD_SRC, "images_groups_folds.csv not found: add the output folder of notebook 01 (citrus_v2_results) via Add Input."
shutil.copy(FOLD_SRC, f"{OUT}/tables/images_groups_folds.csv")
print("Earlier results found in:", prev_dirs)
print("Baseline out-of-fold files restored:", sorted(os.listdir(f"{OUT}/oof_prev")))

import tensorflow as tf
import keras
from keras import layers
random.seed(SEED); np.random.seed(SEED); keras.utils.set_random_seed(SEED)
print("TF", tf.__version__, "| Keras", keras.__version__, "| GPU:", tf.config.list_physical_devices("GPU"))

# %% Cell 3 — Pool all 1,834 images and tag source / organ (unchanged)
#@title Cell 3 — Pool all 1,834 images and tag source / organ (unchanged)
CLASSES = ["Black_Spot", "Canker", "Greening", "Healthy", "Melanose"]
NC = len(CLASSES)
rows = []
for split in ["train", "val", "test"]:
    for c in CLASSES:
        for f in sorted(glob.glob(f"{DATA}/{split}/{c}/*")):
            b = os.path.basename(f)
            src = "Rauf" if b.startswith("citrus_") else ("Silva" if b.startswith("archive1_") else "Other")
            organ = "leaf" if (src == "Rauf" and "Leaves" in b) else "fruit"
            rows.append(dict(path=f, file=b, cls=c, y=CLASSES.index(c), source=src, organ=organ, old_split=split))
df = pd.DataFrame(rows)
N = len(df)
print(N, "images")
display(pd.crosstab([df.source, df.organ], df.cls, margins=True))

def load(p, size=224):
    return np.asarray(Image.open(p).convert("RGB").resize((size, size), Image.BILINEAR), dtype=np.uint8)
X = np.stack([load(p) for p in df.path])
Y = df.y.values.astype("int64")

# %% Cell 4 — Re-use the grouped, stratified 5-fold split of the main benchmark
#@title Cell 4 — Re-use the grouped, stratified 5-fold split of the main benchmark
from sklearn.model_selection import StratifiedGroupKFold
FOLD_CSV = f"{OUT}/tables/images_groups_folds.csv"
reused = False
if os.path.exists(FOLD_CSV):
    prev = pd.read_csv(FOLD_CSV)
    kp = prev.old_split + "|" + prev.cls + "|" + prev.file
    kd = df.old_split + "|" + df.cls + "|" + df.file
    if len(prev) == N and kd.isin(set(kp)).all():
        df["group"] = kd.map(dict(zip(kp, prev.group))).values
        df["fold"] = kd.map(dict(zip(kp, prev.fold))).values.astype(int)
        reused = True
        print("Re-using the group and fold assignment saved by the earlier run (finished folds stay valid).")
assert reused, "The fold file of the main benchmark was not matched; do not continue."
G = df.group.values
if not reused:
    sgkf = StratifiedGroupKFold(n_splits=N_FOLDS, shuffle=True, random_state=SEED)
    df["fold"] = -1
    for k, (_, te) in enumerate(sgkf.split(np.zeros(N), Y, G)):
        df.loc[te, "fold"] = k
display(pd.crosstab(df.fold, df.cls))

def split_fold(k):
    te = np.where(df.fold.values == k)[0]
    rest = np.where(df.fold.values != k)[0]
    inner = StratifiedGroupKFold(n_splits=6, shuffle=True, random_state=SEED + k)
    tr_i, va_i = next(inner.split(np.zeros(len(rest)), Y[rest], G[rest]))
    return rest[tr_i], rest[va_i], te
for k in range(N_FOLDS):
    tr, va, te = split_fold(k)
    assert not (set(G[tr]) & set(G[te])) and not (set(G[va]) & set(G[te])) and not (set(G[tr]) & set(G[va]))
print("Check passed: no near-duplicate group is shared between train, validation and test in any fold.")
df.drop(columns=["path"]).to_csv(f"{OUT}/tables/images_groups_folds.csv", index=False)

# %% Cell 5 — Models, data pipeline, training helpers, object masks and background randomisation
#@title Cell 5 — Models, data pipeline, training helpers, object masks and background randomisation
APPS = {
    "ResNet50": (keras.applications.ResNet50, keras.applications.resnet.preprocess_input),
    "MobileNetV2": (keras.applications.MobileNetV2, keras.applications.mobilenet_v2.preprocess_input),
    "EfficientNetB0": (keras.applications.EfficientNetB0, keras.applications.efficientnet.preprocess_input),
    "DenseNet121": (keras.applications.DenseNet121, keras.applications.densenet.preprocess_input),
    "InceptionV3": (keras.applications.InceptionV3, keras.applications.inception_v3.preprocess_input),
    "EfficientNetV2S": (keras.applications.EfficientNetV2S, keras.applications.efficientnet_v2.preprocess_input),
    "ConvNeXtTiny": (keras.applications.ConvNeXtTiny, keras.applications.convnext.preprocess_input),
}
AUTOTUNE = tf.data.AUTOTUNE
AUG = keras.Sequential([layers.RandomFlip("horizontal_and_vertical"), layers.RandomRotation(0.1), layers.RandomZoom(0.2),
                        layers.RandomContrast(0.2), layers.RandomBrightness(0.2, value_range=(0, 255))])

def build_model(name, n_out):
    ctor, _ = APPS[name]
    inp = keras.Input((224, 224, 3))
    base = ctor(include_top=False, weights="imagenet", input_tensor=inp)
    x = layers.GlobalAveragePooling2D()(base.output)
    x = layers.Dropout(0.3)(x)
    out = layers.Dense(n_out, activation="softmax", dtype="float32")(x)
    return keras.Model(inp, out), base

def _batch_index(ya, seed, n_batches):
    """Square-root class-balanced sampling with replacement (same rule as before), as a fixed index table."""
    rng = np.random.default_rng(seed)
    cls = np.unique(ya); idx = [np.where(ya == c)[0] for c in cls]
    w = np.sqrt([len(i) for i in idx]); w = w / w.sum()
    out = np.empty((n_batches, BATCH), dtype="int64")
    for b in range(n_batches):
        cs = rng.choice(len(cls), size=BATCH, p=w)
        out[b] = [rng.choice(idx[c]) for c in cs]
    return out

def train_ds(Xa, ya, prep):
    with tf.device("/CPU:0"):
        Xt = tf.convert_to_tensor(Xa); yt = tf.convert_to_tensor(np.asarray(ya, dtype="int64"))
    steps = max(1, math.ceil(len(ya) / BATCH))
    ds = tf.data.Dataset.from_tensor_slices(_batch_index(np.asarray(ya), SEED, steps * max(HEAD_EP, FT_EP))).repeat()
    ds = ds.map(lambda i: (tf.gather(Xt, i), tf.gather(yt, i)))
    return ds.map(lambda x, y: (prep(AUG(tf.cast(x, tf.float32), training=True)), y), num_parallel_calls=AUTOTUNE).prefetch(2)

def eval_ds(Xa, prep, ya=None, fn=None):
    if fn is not None:
        Xa = np.stack([fn(x) for x in Xa])
    if ya is None:
        return tf.data.Dataset.from_tensor_slices(Xa).batch(BATCH).map(lambda x: prep(tf.cast(x, tf.float32))).prefetch(2)
    ds = tf.data.Dataset.from_tensor_slices((Xa, np.asarray(ya, dtype="int64"))).batch(BATCH)
    return ds.map(lambda x, y: (prep(tf.cast(x, tf.float32)), y)).prefetch(2)

def ram_gb():
    try:
        import psutil; return psutil.Process().memory_info().rss / 1e9
    except Exception:
        return float("nan")
def ram_limit_gb():
    try:
        import psutil; return 0.75 * psutil.virtual_memory().total / 1e9
    except Exception:
        return 1e9

def free_memory(*objs):
    import gc
    for o in objs: del o
    keras.backend.clear_session(); gc.collect(); gc.collect()

def train_one(name, Xtr, ytr, Xva, yva, n_out):
    keras.backend.clear_session(); keras.utils.set_random_seed(SEED)
    model, base = build_model(name, n_out)
    prep = APPS[name][1]
    tr, va = train_ds(Xtr, ytr, prep), eval_ds(Xva, prep, yva)
    steps = max(1, math.ceil(len(ytr) / BATCH))
    loss = "sparse_categorical_crossentropy"
    for l in base.layers: l.trainable = False
    model.compile(optimizer=keras.optimizers.Adam(1e-3), loss=loss, metrics=["accuracy"])
    model.fit(tr, validation_data=va, epochs=HEAD_EP, steps_per_epoch=steps, verbose=0,
              callbacks=[keras.callbacks.EarlyStopping(monitor="val_loss", patience=3, restore_best_weights=True)])
    for l in base.layers[-FT_LAYERS:]:
        if not isinstance(l, layers.BatchNormalization): l.trainable = True
    model.compile(optimizer=keras.optimizers.Adam(1e-5), loss=loss, metrics=["accuracy"])
    model.fit(tr, validation_data=va, epochs=FT_EP, steps_per_epoch=steps, verbose=0,
              callbacks=[keras.callbacks.EarlyStopping(monitor="val_loss", patience=3, restore_best_weights=True)])
    return model, base

def predict_u8(model, name, Xa, fn=None):
    return model.predict(eval_ds(Xa, APPS[name][1], fn=fn), verbose=0)

def centre_only(x, keep=0.7):
    h = x.shape[0]; m = int(h * (1 - keep) / 2)
    out = np.full_like(x, 124); out[m:h - m, m:h - m] = x[m:h - m, m:h - m]; return out
def corners_only(x, s=56):
    h = x.shape[0]; out = np.full_like(x, 124)
    for r, c in [(0, 0), (0, h - s), (h - s, 0), (h - s, h - s)]:
        out[r:r + s, c:c + s] = x[r:r + s, c:c + s]
    return out

from scipy import ndimage as ndi
from skimage import color, filters, measure
from sklearn.metrics import f1_score, accuracy_score, confusion_matrix
from sklearn.model_selection import StratifiedGroupKFold
from statsmodels.stats.proportion import proportion_confint
from statsmodels.stats.contingency_tables import mcnemar
def object_mask(x):
    """Leaf/fruit mask on plain backgrounds. Black padding or black backdrops are treated as background.
    Returns None when the mask is unreliable (cluttered field scenes, fragmented or tiny/huge masks)."""
    fill = x.max(axis=-1) < 25
    lab = color.rgb2lab(x)
    ring = np.zeros(x.shape[:2], bool); ring[:8] = ring[-8:] = True; ring[:, :8] = ring[:, -8:] = True
    bsel = ring & ~fill
    if bsel.sum() < 0.25 * ring.sum():          # border is mostly black: dark backdrop or padding
        m = ndi.binary_opening(x.max(axis=-1) >= 40, structure=np.ones((5, 5)))
    else:
        d = np.linalg.norm(lab - np.median(lab[bsel], 0), axis=-1); d[fill] = 0
        if (~fill).sum() < 100 or np.ptp(d[~fill]) == 0: return None
        m = ndi.binary_opening(d > filters.threshold_otsu(d[~fill]), structure=np.ones((5, 5))) & ~fill
    lbl = measure.label(m)
    if lbl.max() == 0: return None
    h = x.shape[0]; c0, c1 = h // 4, 3 * h // 4
    centre = np.bincount(lbl[c0:c1, c0:c1].ravel(), minlength=lbl.max() + 1)[1:]
    if centre.max() == 0: return None
    m = ndi.binary_fill_holes(lbl == (int(np.argmax(centre)) + 1))
    if not (0.05 < m.mean() < 0.95): return None
    if measure.regionprops(m.astype(np.uint8))[0].solidity < 0.6: return None   # fragmented -> unreliable
    return m

def randomise_background(x, m):
    """x: float32 batch (0-255), m: float32 masks (1 = leaf/fruit). Keeps the object, replaces the background
    by a random colour or a smooth random texture; images without a reliable mask have m = 1 everywhere."""
    b = tf.shape(x)[0]
    colour = tf.random.uniform((b, 1, 1, 3), 0.0, 255.0) * tf.ones_like(x)
    tex = tf.image.resize(tf.random.uniform((b, 28, 28, 3), 0.0, 255.0), (224, 224), method="bicubic")
    tex = tf.clip_by_value(tf.nn.avg_pool2d(tex, 9, 1, "SAME"), 0.0, 255.0)
    u = tf.random.uniform((b, 1, 1, 1))
    bg = tf.where(u < BR_P_KEEP + BR_P_COLOUR, colour, tex)
    return tf.where(u < BR_P_KEEP, x, m * x + (1.0 - m) * bg)

def train_ds2(Xa, ya, prep, seed, Ma=None):
    with tf.device("/CPU:0"):
        Xt = tf.convert_to_tensor(Xa); yt = tf.convert_to_tensor(np.asarray(ya, dtype="int64"))
        Mt = None if Ma is None else tf.convert_to_tensor(Ma[..., None])
    steps = max(1, math.ceil(len(ya) / BATCH))
    ds = tf.data.Dataset.from_tensor_slices(_batch_index(np.asarray(ya), seed, steps * max(HEAD_EP, FT_EP))).repeat()
    if Mt is None:
        ds = ds.map(lambda i: (tf.gather(Xt, i), tf.gather(yt, i)))
        return ds.map(lambda x, y: (prep(AUG(tf.cast(x, tf.float32), training=True)), y), num_parallel_calls=AUTOTUNE).prefetch(2)
    ds = ds.map(lambda i: (tf.gather(Xt, i), tf.gather(Mt, i), tf.gather(yt, i)))
    return ds.map(lambda x, m, y: (prep(AUG(randomise_background(tf.cast(x, tf.float32), tf.cast(m, tf.float32)), training=True)), y),
                  num_parallel_calls=AUTOTUNE).prefetch(2)

def train_two(name, Xtr, ytr, Xva, yva, n_out, Mtr=None, seed=SEED):
    """Same two-stage recipe as the main benchmark; Mtr=None gives the baseline, masks give background randomisation."""
    keras.backend.clear_session(); keras.utils.set_random_seed(seed)
    model, base = build_model(name, n_out)
    prep = APPS[name][1]
    tr, va = train_ds2(Xtr, ytr, prep, seed, Mtr), eval_ds(Xva, prep, yva)
    steps = max(1, math.ceil(len(ytr) / BATCH))
    loss = "sparse_categorical_crossentropy"
    for l in base.layers: l.trainable = False
    model.compile(optimizer=keras.optimizers.Adam(1e-3), loss=loss, metrics=["accuracy"])
    model.fit(tr, validation_data=va, epochs=HEAD_EP, steps_per_epoch=steps, verbose=0,
              callbacks=[keras.callbacks.EarlyStopping(monitor="val_loss", patience=3, restore_best_weights=True)])
    for l in base.layers[-FT_LAYERS:]:
        if not isinstance(l, layers.BatchNormalization): l.trainable = True
    model.compile(optimizer=keras.optimizers.Adam(1e-5), loss=loss, metrics=["accuracy"])
    model.fit(tr, validation_data=va, epochs=FT_EP, steps_per_epoch=steps, verbose=0,
              callbacks=[keras.callbacks.EarlyStopping(monitor="val_loss", patience=3, restore_best_weights=True)])
    return model, base

def mf1(y, p, labels=None):
    return f1_score(y, p, average="macro", labels=labels if labels is not None else np.unique(y), zero_division=0)
def wilson(c, n):
    lo, hi = proportion_confint(c, n, method="wilson"); return f"{lo:.3f}-{hi:.3f}"
def append_log(path, row):
    L = pd.read_csv(path) if os.path.exists(path) else pd.DataFrame()
    pd.concat([L, pd.DataFrame([row])], ignore_index=True).to_csv(path, index=False)

# %% Cell 6 — Object masks for all images (+ example figure of background randomisation)
#@title Cell 6 — Object masks for all images (+ example figure of background randomisation)
M = np.ones((N, 224, 224), dtype=np.uint8); ok = np.zeros(N, dtype=bool)
for i in range(N):
    m = object_mask(X[i])
    if m is not None:
        M[i] = ndi.binary_dilation(m, iterations=3).astype(np.uint8); ok[i] = True
df["mask_ok"] = ok
print("Reliable object masks:", int(ok.sum()), "of", N, "(images without a reliable mask are trained unchanged)")
display(pd.crosstab([df.source, df.organ], df.mask_ok))
X_grey = np.where(M[..., None] > 0, X, np.uint8(124))          # object on a neutral grey background (test-time variant)
df[["file", "cls", "source", "organ", "mask_ok"]].to_csv(f"{OUT}/tables/mask_coverage.csv", index=False)

rng_ex = np.random.default_rng(SEED)
ex = [int(i) for s, o in [("Rauf", "leaf"), ("Silva", "fruit")]
      for i in rng_ex.choice(np.where((df.source == s) & (df.organ == o) & df.mask_ok)[0], 2, replace=False)]
xb = tf.constant(X[ex].astype("float32")); mb = tf.constant(M[ex][..., None].astype("float32"))
tf.random.set_seed(SEED)
col = (mb * xb + (1 - mb) * tf.random.uniform((len(ex), 1, 1, 3), 0.0, 255.0)).numpy()
tex = tf.clip_by_value(tf.nn.avg_pool2d(tf.image.resize(tf.random.uniform((len(ex), 28, 28, 3), 0.0, 255.0), (224, 224), method="bicubic"), 9, 1, "SAME"), 0, 255)
tex = (mb * xb + (1 - mb) * tex).numpy()
fig, axs = plt.subplots(len(ex), 4, figsize=(8, 2 * len(ex)))
for r, i in enumerate(ex):
    for c, (im, t) in enumerate([(X[i], "original"), (M[i] * 255, "object mask"), (col[r], "random colour"), (tex[r], "random texture")]):
        axs[r, c].imshow(np.asarray(im).astype(np.uint8), cmap="gray" if c == 1 else None); axs[r, c].axis("off")
        if r == 0: axs[r, c].set_title(t, fontsize=9)
plt.tight_layout(); plt.savefig(f"{OUT}/figures/background_randomisation_examples.png", dpi=200); plt.close()
print("Saved figure: background_randomisation_examples.png")

# %% Cell 7 — Experiment A1: background-randomised training, same grouped 5-fold split (resumable)
#@title Cell 7 — Experiment A1: background-randomised training, same grouped 5-fold split (resumable)
LOG_A1 = f"{OUT}/tables/br_cv_log.csv"
done = pd.read_csv(LOG_A1) if os.path.exists(LOG_A1) else pd.DataFrame(columns=["model", "fold"])
for name in EXP_MODELS:
    for k in range(N_FOLDS):
        if ((done.model == name) & (done.fold == k)).any():
            print("skip (already done):", name, k); continue
        t0 = time.time()
        tr, va, te = split_fold(k)
        model, base = train_two(name, X[tr], Y[tr], X[va], Y[va], NC, Mtr=M[tr], seed=SEED)
        pf = predict_u8(model, name, X[te]); pg = predict_u8(model, name, X_grey[te])
        pk = predict_u8(model, name, X[te], fn=corners_only); pc = predict_u8(model, name, X[te], fn=centre_only)
        np.savez_compressed(f"{OUT}/oof_br/{name}_fold{k}.npz", te=te, p_full=pf, p_grey=pg, p_corners=pk, p_centre=pc)
        row = dict(model=name, fold=k, n_test=len(te), acc_full=accuracy_score(Y[te], pf.argmax(1)), macro_f1=mf1(Y[te], pf.argmax(1)),
                   acc_grey=accuracy_score(Y[te], pg.argmax(1)), acc_corners=accuracy_score(Y[te], pk.argmax(1)),
                   acc_centre=accuracy_score(Y[te], pc.argmax(1)), minutes=(time.time() - t0) / 60)
        append_log(LOG_A1, row); done = pd.read_csv(LOG_A1)
        print({a: (round(b, 3) if isinstance(b, float) else b) for a, b in row.items()}, "| RAM", round(ram_gb(), 1), "GB")
        del model, base; free_memory()

# %% Cell 8 — Experiment A2: cross-dataset transfer, baseline vs background-randomised, 3 seeds (resumable)
#@title Cell 8 — Experiment A2: cross-dataset transfer, baseline vs background-randomised, 3 seeds (resumable)
SHARED = ["Black_Spot", "Canker", "Greening", "Healthy"]
src, org = df.source.values, df.organ.values
def sub(mask):
    ii = np.where(mask & np.isin(df.cls.values, SHARED))[0]
    return ii, np.array([SHARED.index(c) for c in df.cls.values[ii]], dtype="int64")
TRANSFER = {"OrangeDiseases_to_Sargodha": (src == "Silva", [("Sargodha fruit (organ-matched)", (src == "Rauf") & (org == "fruit")),
                                                             ("Sargodha leaves (organ-mismatched)", (src == "Rauf") & (org == "leaf"))]),
            "Sargodha_to_OrangeDiseases": (src == "Rauf", [("Orange Diseases fruit", src == "Silva")])}
LOG_A2 = f"{OUT}/tables/br_transfer_log.csv"
for name in EXP_MODELS:
    for method in ["baseline", "background_randomised"]:
        for s in SEEDS:
            for tag, (trmask, tests) in TRANSFER.items():
                L = pd.read_csv(LOG_A2) if os.path.exists(LOG_A2) else pd.DataFrame(columns=["model", "method", "seed", "train"])
                if ((L.model == name) & (L.method == method) & (L.seed == s) & (L.train == tag)).any():
                    print("skip (already done):", name, method, s, tag); continue
                ii, yy = sub(trmask)
                tr_i, va_i = next(StratifiedGroupKFold(n_splits=6, shuffle=True, random_state=SEED + s).split(np.zeros(len(ii)), yy, G[ii]))
                model, base = train_two(name, X[ii[tr_i]], yy[tr_i], X[ii[va_i]], yy[va_i], len(SHARED),
                                        Mtr=None if method == "baseline" else M[ii[tr_i]], seed=s)
                rows = []
                for tname, tmask in tests:
                    jj, yj = sub(tmask)
                    for variant, XX in [("original", X), ("grey_background", X_grey)]:
                        p = predict_u8(model, name, XX[jj]).argmax(1); c = int((p == yj).sum())
                        rows.append(dict(model=name, method=method, seed=s, train=tag, test=tname, variant=variant, n=len(jj),
                                         acc=c / len(jj), acc_ci95=wilson(c, len(jj)), macro_f1=mf1(yj, p, labels=list(range(len(SHARED))))))
                L = pd.read_csv(LOG_A2) if os.path.exists(LOG_A2) else pd.DataFrame()
                pd.concat([L, pd.DataFrame(rows)], ignore_index=True).to_csv(LOG_A2, index=False)
                print(name, method, "seed", s, tag, [f"{r['test'][:22]}|{r['variant'][:4]}: {r['acc']:.3f}" for r in rows])
                del model, base; free_memory()

# %% Cell 9 — Experiment B: external test on independent sweet-orange leaves (Emon et al.), 3 seeds (resumable)
#@title Cell 9 — Experiment B: external test on independent sweet-orange leaves (Emon et al.), 3 seeds (resumable)
IMG_EXT = (".jpg", ".jpeg", ".png", ".bmp")
def find_external():
    roots = [EXTERNAL_DIR] if EXTERNAL_DIR else [d for d in glob.glob(f"{INPUT_ROOT}/**/", recursive=False)]
    hits = []
    for root, dirs, files in os.walk(EXTERNAL_DIR or INPUT_ROOT):
        low = root.lower()
        if any(s in low for s in ["split_dataset", "citrus_v2", "citrus_v3", "/notebooks/"]):
            continue
        if any(s in low for s in EXT_EXCLUDE):
            continue
        cls_dir = os.path.basename(root).lower()
        lab = next((v for k, v in EXT_CLASS_MAP.items() if k in cls_dir), None)
        if lab is None:
            continue
        imgs = [f for f in files if f.lower().endswith(IMG_EXT)]
        if imgs:
            hits.append((os.path.dirname(root), root, lab, imgs))
    return hits
hits = find_external()
if not hits:
    print("No external dataset found under", INPUT_ROOT, "- add the Emon sweet-orange dataset via Add Input. Cell skipped.")
else:
    fmt = pd.DataFrame([(h[0], h[2], len(h[3])) for h in hits], columns=["format_dir", "class", "n"])
    display(fmt)
    per_fmt = fmt.groupby("format_dir").n.sum()
    pref = [d for d in per_fmt.index if any(k in d.lower() for k in ["original", "raw"])]
    FMT = pref[0] if pref else per_fmt.idxmax()           # one format only, so the same leaf is never counted twice
    print("Using external images from:", FMT)
    ext = [(os.path.join(h[1], f), h[2]) for h in hits if h[0] == FMT for f in sorted(h[3])]
    Xe = np.stack([load(p) for p, _ in ext]); ye = np.array([CLASSES.index(c) for _, c in ext])
    present = sorted(set(ye.tolist())); keep = np.array(present)
    print("External images:", len(ye), {CLASSES[c]: int((ye == c).sum()) for c in present})
    Me = np.ones((len(ye), 224, 224), dtype=np.uint8); oke = np.zeros(len(ye), bool)
    for i in range(len(ye)):
        m = object_mask(Xe[i])
        if m is not None: Me[i] = ndi.binary_dilation(m, iterations=3).astype(np.uint8); oke[i] = True
    print("External images with a reliable object mask:", int(oke.sum()))
    Xe_grey = np.where(Me[..., None] > 0, Xe, np.uint8(124))
    pd.DataFrame({"file": [p for p, _ in ext], "cls": [c for _, c in ext], "mask_ok": oke}).to_csv(f"{OUT}/tables/external_images.csv", index=False)
    LOG_B = f"{OUT}/tables/external_test_log.csv"
    for name in EXP_MODELS:
        for method in ["baseline", "background_randomised"]:
            for s in SEEDS:
                L = pd.read_csv(LOG_B) if os.path.exists(LOG_B) else pd.DataFrame(columns=["model", "method", "seed"])
                if ((L.model == name) & (L.method == method) & (L.seed == s)).any():
                    print("skip (already done):", name, method, s); continue
                tr_i, va_i = next(StratifiedGroupKFold(n_splits=6, shuffle=True, random_state=SEED + s).split(np.zeros(N), Y, G))
                model, base = train_two(name, X[tr_i], Y[tr_i], X[va_i], Y[va_i], NC, Mtr=None if method == "baseline" else M[tr_i], seed=s)
                rows = []
                for variant, XX in [("original", Xe), ("grey_background", Xe_grey)]:
                    P = predict_u8(model, name, XX); pe = keep[P[:, keep].argmax(1)]; c = int((pe == ye).sum())
                    np.savez_compressed(f"{OUT}/preds/external_{name}_{method}_seed{s}_{variant}.npz", P=P, y=ye)
                    r = dict(model=name, method=method, seed=s, variant=variant, n=len(ye), acc=c / len(ye), acc_ci95=wilson(c, len(ye)),
                             macro_f1=mf1(ye, pe, labels=present))
                    for cc in present: r[f"recall_{CLASSES[cc]}"] = float((pe[ye == cc] == cc).mean())
                    rows.append(r)
                L = pd.read_csv(LOG_B) if os.path.exists(LOG_B) else pd.DataFrame()
                pd.concat([L, pd.DataFrame(rows)], ignore_index=True).to_csv(LOG_B, index=False)
                print(name, method, "seed", s, [f"{r['variant'][:4]}: acc {r['acc']:.3f} F1 {r['macro_f1']:.3f}" for r in rows])
                del model, base; free_memory()

# %% Cell 10 — Summary tables for the paper
#@title Cell 10 — Summary tables for the paper
out = []
for name in EXP_MODELS:
    P0, P1 = {}, {}
    for k in range(N_FOLDS):
        a = np.load(f"{OUT}/oof_prev/{name}_fold{k}.npz"); b = np.load(f"{OUT}/oof_br/{name}_fold{k}.npz")
        for i, p, pk, pc in zip(a["te"], a["p_full"].argmax(1), a["p_corners"].argmax(1), a["p_centre"].argmax(1)): P0[i] = (p, pk, pc)
        for i, p, pg, pk, pc in zip(b["te"], b["p_full"].argmax(1), b["p_grey"].argmax(1), b["p_corners"].argmax(1), b["p_centre"].argmax(1)): P1[i] = (p, pg, pk, pc)
    idx = np.array(sorted(P0)); assert len(idx) == N and sorted(P1) == list(idx)
    b0 = np.array([P0[i][0] for i in idx]); b1 = np.array([P1[i][0] for i in idx]); y = Y[idx]
    c0, c1 = b0 == y, b1 == y
    tbl = [[int((c0 & c1).sum()), int((c0 & ~c1).sum())], [int((~c0 & c1).sum()), int((~c0 & ~c1).sum())]]
    pmc = mcnemar(tbl, exact=True).pvalue
    for method, pr, pk, pc, pg in [("baseline", b0, np.array([P0[i][1] for i in idx]), np.array([P0[i][2] for i in idx]), None),
                                   ("background_randomised", b1, np.array([P1[i][2] for i in idx]), np.array([P1[i][3] for i in idx]), np.array([P1[i][1] for i in idx]))]:
        r = dict(model=name, method=method, n=N, acc=(pr == y).mean(), acc_ci95=wilson(int((pr == y).sum()), N), macro_f1=mf1(y, pr),
                 acc_corners_only=(pk == y).mean(), acc_centre_only=(pc == y).mean(),
                 acc_grey_background=(pg == y).mean() if pg is not None else np.nan,
                 mcnemar_p_vs_baseline=pmc if method != "baseline" else np.nan)
        for s_ in ["Rauf", "Silva"]:
            for o_ in ["leaf", "fruit"]:
                mm = (df.source.values[idx] == s_) & (df.organ.values[idx] == o_)
                if mm.any(): r[f"acc_{s_}_{o_}"] = (pr[mm] == y[mm]).mean()
        out.append(r)
A1 = pd.DataFrame(out); A1.to_csv(f"{OUT}/tables/A1_cv_baseline_vs_background_randomised.csv", index=False); display(A1.round(3))
if os.path.exists(f"{OUT}/tables/br_transfer_log.csv"):
    T = pd.read_csv(f"{OUT}/tables/br_transfer_log.csv")
    A2 = T.groupby(["model", "train", "test", "variant", "method"]).agg(n=("n", "first"), acc_mean=("acc", "mean"), acc_sd=("acc", "std"),
                                                                       f1_mean=("macro_f1", "mean"), f1_sd=("macro_f1", "std"), seeds=("seed", "nunique")).reset_index()
    A2.to_csv(f"{OUT}/tables/A2_transfer_summary.csv", index=False); display(A2.round(3))
if os.path.exists(f"{OUT}/tables/external_test_log.csv"):
    E_ = pd.read_csv(f"{OUT}/tables/external_test_log.csv")
    agg = {"n": ("n", "first"), "acc_mean": ("acc", "mean"), "acc_sd": ("acc", "std"), "f1_mean": ("macro_f1", "mean"), "f1_sd": ("macro_f1", "std")}
    for c in [c for c in E_.columns if c.startswith("recall_")]: agg[c] = (c, "mean")
    B_ = E_.groupby(["model", "variant", "method"]).agg(**agg).reset_index()
    B_.to_csv(f"{OUT}/tables/B_external_summary.csv", index=False); display(B_.round(3))

# %% Cell 11 — Pack results (send citrus_v3_results_upload.zip)
#@title Cell 11 — Pack results (send citrus_v3_results_upload.zip)
pack = "/kaggle/temp/pack_v3"
shutil.rmtree(pack, ignore_errors=True)
shutil.copytree(f"{OUT}/tables", f"{pack}/tables"); shutil.copytree(f"{OUT}/figures", f"{pack}/figures")
z = shutil.make_archive("/kaggle/working/citrus_v3_results_upload", "zip", pack)
print("Send me this file:", z)
